import { describe, it, expect } from 'vitest';

describe('Controle Financeiro - Content Validation', () => {
  it('should have receitas com categoria', () => {
    const receitas = [
      { descricao: 'Venda de Soja', valor: 45000, categoria: 'Venda' },
      { descricao: 'Venda de Milho', valor: 32000, categoria: 'Venda' },
      { descricao: 'Venda de Gado', valor: 28000, categoria: 'Pecuária' },
    ];
    expect(receitas).toHaveLength(3);
    receitas.forEach((r) => {
      expect(r.categoria).toBeTruthy();
    });
  });

  it('should have despesas com categoria', () => {
    const despesas = [
      { descricao: 'Fertilizante', valor: 8000, categoria: 'Insumos' },
      { descricao: 'Combustível', valor: 5000, categoria: 'Operacional' },
      { descricao: 'Manutenção Trator', valor: 3500, categoria: 'Manutenção' },
    ];
    expect(despesas).toHaveLength(3);
  });

  it('should calculate total receita', () => {
    const receitas = [
      { valor: 45000 },
      { valor: 32000 },
      { valor: 28000 },
    ];
    const total = receitas.reduce((sum, r) => sum + r.valor, 0);
    expect(total).toBe(105000);
  });

  it('should calculate total despesa', () => {
    const despesas = [
      { valor: 8000 },
      { valor: 5000 },
      { valor: 3500 },
    ];
    const total = despesas.reduce((sum, d) => sum + d.valor, 0);
    expect(total).toBe(16500);
  });

  it('should calculate lucro liquido', () => {
    const receita = 250000;
    const despesa = 95000;
    const lucro = receita - despesa;
    expect(lucro).toBe(155000);
  });

  it('should calculate margem de lucro', () => {
    const receita = 250000;
    const lucro = 155000;
    const margem = (lucro / receita) * 100;
    expect(margem).toBeCloseTo(62, 0);
  });

  it('should have fluxo de caixa por mes', () => {
    const fluxo = [
      { mes: 'Jan', receita: 45000, despesa: 18000 },
      { mes: 'Fev', receita: 52000, despesa: 22000 },
      { mes: 'Mar', receita: 48000, despesa: 20000 },
      { mes: 'Abr', receita: 55000, despesa: 23000 },
      { mes: 'Mai', receita: 50000, despesa: 21000 },
    ];
    expect(fluxo).toHaveLength(5);
  });

  it('should have categorias de despesas', () => {
    const categorias = [
      { name: 'Insumos', value: 35 },
      { name: 'Operacional', value: 25 },
      { name: 'Manutenção', value: 20 },
      { name: 'Pessoal', value: 20 },
    ];
    const total = categorias.reduce((sum, c) => sum + c.value, 0);
    expect(total).toBe(100);
  });

  it('should calculate ROI', () => {
    const investimento = 95000;
    const lucro = 155000;
    const roi = (lucro / investimento) * 100;
    expect(roi).toBeCloseTo(163, 0);
  });
});
