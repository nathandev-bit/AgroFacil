import { useAuth } from '@/_core/hooks/useAuth';
import DashboardLayout from '@/components/DashboardLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  TrendingUp,
  TrendingDown,
  AlertCircle,
  Bell,
  LineChart,
  MapPin,
} from 'lucide-react';
import { LineChart as LineChartComponent, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

/**
 * Mercado Agro
 * Cotações em tempo real, histórico de preços e rede colaborativa
 */
export default function MercadoAgro() {
  const { user } = useAuth();

  const cotacoes = [
    { id: 1, produto: 'Soja', preco: 65.50, variacao: 2.3, tendencia: 'up' },
    { id: 2, produto: 'Milho', preco: 38.20, variacao: -1.2, tendencia: 'down' },
    { id: 3, produto: 'Boi Gordo', preco: 285.00, variacao: 0.8, tendencia: 'up' },
    { id: 4, produto: 'Leite', preco: 1.85, variacao: 1.5, tendencia: 'up' },
    { id: 5, produto: 'Café', preco: 450.00, variacao: -0.5, tendencia: 'down' },
    { id: 6, produto: 'Algodão', preco: 95.30, variacao: 3.2, tendencia: 'up' },
    { id: 7, produto: 'Arroz', preco: 42.10, variacao: 0.3, tendencia: 'up' },
    { id: 8, produto: 'Feijão', preco: 68.50, variacao: 2.1, tendencia: 'up' },
  ];

  const historicoPrecos = [
    { data: '01/05', soja: 64, milho: 37.5, boi: 283 },
    { data: '05/05', soja: 64.5, milho: 37.8, boi: 284 },
    { data: '10/05', soja: 65, milho: 38, boi: 284.5 },
    { data: '15/05', soja: 65.2, milho: 38.1, boi: 285 },
    { data: '20/05', soja: 65.5, milho: 38.2, boi: 285 },
  ];

  const alertasColaborativos = [
    { id: 1, regiao: 'Mato Grosso', praga: 'Broca do Milho', severidade: 'Alta', usuarios: 12 },
    { id: 2, regiao: 'São Paulo', praga: 'Ferrugem Asiática', severidade: 'Média', usuarios: 8 },
    { id: 3, regiao: 'Paraná', praga: 'Cigarrinha do Milho', severidade: 'Alta', usuarios: 15 },
    { id: 4, regiao: 'Goiás', praga: 'Lagarta-do-Cartucho', severidade: 'Baixa', usuarios: 5 },
  ];

  const minhasAlertasAgricultor = [
    { id: 1, titulo: 'Broca detectada em meu talhão', data: '2 horas atrás', confirmacoes: 3 },
    { id: 2, titulo: 'Ferrugem em região próxima', data: '1 dia atrás', confirmacoes: 8 },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold">Mercado Agro</h1>
          <p className="text-muted-foreground mt-2">
            Cotações em tempo real, histórico de preços e rede colaborativa de alertas
          </p>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="cotacoes" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="cotacoes">Cotações</TabsTrigger>
            <TabsTrigger value="historico">Histórico</TabsTrigger>
            <TabsTrigger value="rede">Rede Colaborativa</TabsTrigger>
          </TabsList>

          {/* Cotações Tab */}
          <TabsContent value="cotacoes" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {cotacoes.map((cot) => (
                <Card key={cot.id} className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="font-semibold">{cot.produto}</h3>
                    {cot.tendencia === 'up' ? (
                      <TrendingUp className="h-5 w-5 text-green-600" />
                    ) : (
                      <TrendingDown className="h-5 w-5 text-red-600" />
                    )}
                  </div>
                  <p className="text-2xl font-bold mb-2">R$ {cot.preco.toFixed(2)}</p>
                  <p className={`text-sm ${cot.tendencia === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                    {cot.tendencia === 'up' ? '+' : ''}{cot.variacao}%
                  </p>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Histórico Tab */}
          <TabsContent value="historico" className="space-y-4">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Últimos 20 Dias</h3>
              <ResponsiveContainer width="100%" height={300}>
                <LineChartComponent data={historicoPrecos}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="data" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="soja" stroke="#10b981" name="Soja" />
                  <Line type="monotone" dataKey="milho" stroke="#f59e0b" name="Milho" />
                  <Line type="monotone" dataKey="boi" stroke="#ef4444" name="Boi Gordo" />
                </LineChartComponent>
              </ResponsiveContainer>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Análise de Tendências</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span>Soja</span>
                  <span className="text-green-600 font-semibold">+2.3% ↑</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Milho</span>
                  <span className="text-red-600 font-semibold">-1.2% ↓</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Boi Gordo</span>
                  <span className="text-green-600 font-semibold">+0.8% ↑</span>
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* Rede Colaborativa Tab */}
          <TabsContent value="rede" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* Alertas Colaborativos */}
              <div className="space-y-4">
                <h3 className="font-semibold text-lg">Alertas da Rede AgroFácil</h3>
                {alertasColaborativos.map((alerta) => (
                  <Card key={alerta.id} className="p-4 border-l-4 border-yellow-500">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="h-5 w-5 text-yellow-600 mt-1" />
                      <div className="flex-1">
                        <p className="font-semibold">{alerta.praga}</p>
                        <p className="text-sm text-muted-foreground">{alerta.regiao}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <span className={`text-xs px-2 py-1 rounded ${
                            alerta.severidade === 'Alta' ? 'bg-red-100 text-red-700' :
                            alerta.severidade === 'Média' ? 'bg-yellow-100 text-yellow-700' :
                            'bg-green-100 text-green-700'
                          }`}>
                            {alerta.severidade}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {alerta.usuarios} agricultores
                          </span>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              {/* Meus Alertas */}
              <div className="space-y-4">
                <h3 className="font-semibold text-lg">Meus Alertas</h3>
                {minhasAlertasAgricultor.map((alerta) => (
                  <Card key={alerta.id} className="p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="font-semibold">{alerta.titulo}</p>
                        <p className="text-sm text-muted-foreground">{alerta.data}</p>
                        <p className="text-xs text-muted-foreground mt-2">
                          {alerta.confirmacoes} confirmações
                        </p>
                      </div>
                      <Button variant="outline" size="sm" className="gap-1">
                        <Bell className="h-4 w-4" />
                        Notificar
                      </Button>
                    </div>
                  </Card>
                ))}
                <Button className="w-full gap-2">
                  <AlertCircle className="h-4 w-4" />
                  Reportar Novo Alerta
                </Button>
              </div>
            </div>

            {/* Estatísticas da Rede */}
            <Card className="p-6 bg-gradient-to-br from-blue-50 to-cyan-50">
              <h3 className="font-semibold text-lg mb-4">Estatísticas da Rede AgroFácil</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Agricultores Conectados</p>
                  <p className="text-2xl font-bold text-blue-600 mt-1">1.245</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Alertas Ativos</p>
                  <p className="text-2xl font-bold text-orange-600 mt-1">42</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Regiões Monitoradas</p>
                  <p className="text-2xl font-bold text-green-600 mt-1">27</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Pragas Detectadas</p>
                  <p className="text-2xl font-bold text-red-600 mt-1">18</p>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
