import { describe, it, expect } from 'vitest';

describe('Gestão de Funcionários - Content Validation', () => {
  it('should have funcionarios', () => {
    const funcionarios = [
      { nome: 'João da Silva', cargo: 'Operador de Máquinas' },
      { nome: 'Maria Santos', cargo: 'Técnica Agrícola' },
      { nome: 'Pedro Oliveira', cargo: 'Peão de Fazenda' },
      { nome: 'Ana Costa', cargo: 'Veterinária' },
    ];
    expect(funcionarios).toHaveLength(4);
  });

  it('should have folha de pagamento', () => {
    const folha = [
      { funcionario: 'João da Silva', salario: 3500, liquido: 3350 },
      { funcionario: 'Maria Santos', salario: 4000, liquido: 3900 },
      { funcionario: 'Pedro Oliveira', salario: 2800, liquido: 2620 },
      { funcionario: 'Ana Costa', salario: 5000, liquido: 5000 },
    ];
    expect(folha).toHaveLength(4);
  });

  it('should calculate total folha', () => {
    const folha = [
      { salario: 3500 },
      { salario: 4000 },
      { salario: 2800 },
      { salario: 5000 },
    ];
    const total = folha.reduce((sum, f) => sum + f.salario, 0);
    expect(total).toBe(15300);
  });

  it('should have escala de trabalho', () => {
    const escala = [
      { funcionario: 'João da Silva', turno: 'Manhã' },
      { funcionario: 'Maria Santos', turno: 'Tarde' },
      { funcionario: 'Pedro Oliveira', turno: 'Manhã' },
      { funcionario: 'Ana Costa', turno: 'Tarde' },
    ];
    expect(escala).toHaveLength(4);
  });

  it('should have atividades', () => {
    const atividades = [
      { funcionario: 'João da Silva', horas: 8 },
      { funcionario: 'Maria Santos', horas: 6 },
      { funcionario: 'Pedro Oliveira', horas: 8 },
      { funcionario: 'Ana Costa', horas: 7 },
    ];
    expect(atividades).toHaveLength(4);
  });

  it('should calculate total horas trabalhadas', () => {
    const atividades = [
      { horas: 8 },
      { horas: 6 },
      { horas: 8 },
      { horas: 7 },
    ];
    const total = atividades.reduce((sum, a) => sum + a.horas, 0);
    expect(total).toBe(29);
  });

  it('should calculate liquido after deductions', () => {
    const salario = 3500;
    const bonus = 200;
    const desconto = 350;
    const liquido = salario + bonus - desconto;
    expect(liquido).toBe(3350);
  });
});
