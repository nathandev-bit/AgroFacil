import { describe, it, expect } from 'vitest';

describe('Controle de Estoque - Content Validation', () => {
  it('should have fertilizantes', () => {
    const fertilizantes = [
      { nome: 'Ureia', quantidade: 500 },
      { nome: 'Superfosfato', quantidade: 300 },
      { nome: 'Cloreto de Potássio', quantidade: 45 },
    ];
    expect(fertilizantes).toHaveLength(3);
  });

  it('should have defensivos', () => {
    const defensivos = [
      { nome: 'Inseticida A', quantidade: 120 },
      { nome: 'Fungicida B', quantidade: 80 },
      { nome: 'Herbicida C', quantidade: 200 },
    ];
    expect(defensivos).toHaveLength(3);
  });

  it('should have racoes', () => {
    const racoes = [
      { nome: 'Ração Gado Corte', quantidade: 2000 },
      { nome: 'Ração Gado Leite', quantidade: 1500 },
      { nome: 'Ração Suíno', quantidade: 800 },
    ];
    expect(racoes).toHaveLength(3);
  });

  it('should have medicamentos', () => {
    const medicamentos = [
      { nome: 'Antibiótico Injetável', quantidade: 50 },
      { nome: 'Vitamina Complexo', quantidade: 100 },
      { nome: 'Antiparasitário', quantidade: 75 },
    ];
    expect(medicamentos).toHaveLength(3);
  });

  it('should detect low stock items', () => {
    const items = [
      { quantidade: 45, minimo: 200 },
      { quantidade: 80, minimo: 100 },
    ];
    const lowStock = items.filter((i) => i.quantidade < i.minimo);
    expect(lowStock).toHaveLength(2);
  });
});
