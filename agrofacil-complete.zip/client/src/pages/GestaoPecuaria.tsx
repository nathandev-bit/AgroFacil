import { useAuth } from '@/_core/hooks/useAuth';
import DashboardLayout from '@/components/DashboardLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Plus,
  Heart,
  Syringe,
  AlertCircle,
  BarChart3,
  Calendar,
  Weight,
  Zap,
} from 'lucide-react';

/**
 * Gestão Pecuária
 * Cadastro de animais, vacinações, saúde, reprodução e medicamentos
 */
export default function GestaoPecuaria() {
  const { user } = useAuth();

  const animais = [
    { id: 1, numero: '001', raca: 'Nelore', peso: 450, idade: 3, status: 'Saudável' },
    { id: 2, numero: '002', raca: 'Nelore', peso: 480, idade: 4, status: 'Saudável' },
    { id: 3, numero: '003', raca: 'Angus', peso: 520, idade: 5, status: 'Observação' },
  ];

  const vacinacoes = [
    { id: 1, animal: '001', vacina: 'Aftosa', data: '2026-05-15', proxima: '2026-11-15' },
    { id: 2, animal: '002', vacina: 'Brucelose', data: '2026-04-20', proxima: '2027-04-20' },
    { id: 3, animal: '003', vacina: 'Raiva', data: '2026-05-10', proxima: '2027-05-10' },
  ];

  const medicamentos = [
    { id: 1, animal: '003', medicamento: 'Antibiótico', data: '2026-05-20', motivo: 'Inflamação' },
    { id: 2, animal: '001', medicamento: 'Vermífugo', data: '2026-05-18', motivo: 'Prevenção' },
  ];

  const reproducao = [
    { id: 1, femea: '001', macho: '002', data: '2026-05-15', status: 'Confirmada' },
    { id: 2, femea: '003', macho: '002', data: '2026-05-10', status: 'Pendente' },
  ];

  const alertas = [
    { id: 1, animal: '003', tipo: 'Saúde', mensagem: 'Animal em observação - febre detectada' },
    { id: 2, animal: '001', tipo: 'Vacinação', mensagem: 'Próxima vacinação em 10 dias' },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Gestão Pecuária</h1>
            <p className="text-muted-foreground mt-2">
              Animais, vacinações, saúde, reprodução e medicamentos
            </p>
          </div>
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Novo Animal
          </Button>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="animais" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="animais">Animais</TabsTrigger>
            <TabsTrigger value="vacinacoes">Vacinações</TabsTrigger>
            <TabsTrigger value="medicamentos">Medicamentos</TabsTrigger>
            <TabsTrigger value="reproducao">Reprodução</TabsTrigger>
            <TabsTrigger value="alertas">Alertas</TabsTrigger>
          </TabsList>

          {/* Animais Tab */}
          <TabsContent value="animais" className="space-y-4">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b">
                  <tr>
                    <th className="text-left py-3 px-4">Número</th>
                    <th className="text-left py-3 px-4">Raça</th>
                    <th className="text-left py-3 px-4">Peso (kg)</th>
                    <th className="text-left py-3 px-4">Idade (anos)</th>
                    <th className="text-left py-3 px-4">Status</th>
                    <th className="text-left py-3 px-4">Ação</th>
                  </tr>
                </thead>
                <tbody>
                  {animais.map((animal) => (
                    <tr key={animal.id} className="border-b hover:bg-muted/50">
                      <td className="py-3 px-4 font-semibold">{animal.numero}</td>
                      <td className="py-3 px-4">{animal.raca}</td>
                      <td className="py-3 px-4">{animal.peso}</td>
                      <td className="py-3 px-4">{animal.idade}</td>
                      <td className="py-3 px-4">
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          animal.status === 'Saudável' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                        }`}>
                          {animal.status}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <Button variant="ghost" size="sm">Detalhes</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </TabsContent>

          {/* Vacinações Tab */}
          <TabsContent value="vacinacoes" className="space-y-4">
            <div className="space-y-3">
              {vacinacoes.map((vacinacao) => (
                <Card key={vacinacao.id} className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4">
                      <Syringe className="h-6 w-6 text-blue-600 mt-1" />
                      <div>
                        <p className="font-semibold">Animal {vacinacao.animal} - {vacinacao.vacina}</p>
                        <p className="text-sm text-muted-foreground">Aplicada em: {vacinacao.data}</p>
                        <p className="text-sm mt-2">Próxima dose: <strong>{vacinacao.proxima}</strong></p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">Registrar</Button>
                  </div>
                </Card>
              ))}
            </div>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Nova Vacinação
            </Button>
          </TabsContent>

          {/* Medicamentos Tab */}
          <TabsContent value="medicamentos" className="space-y-4">
            <div className="space-y-3">
              {medicamentos.map((med) => (
                <Card key={med.id} className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4">
                      <Zap className="h-6 w-6 text-purple-600 mt-1" />
                      <div>
                        <p className="font-semibold">Animal {med.animal} - {med.medicamento}</p>
                        <p className="text-sm text-muted-foreground">Data: {med.data}</p>
                        <p className="text-sm mt-2">Motivo: <strong>{med.motivo}</strong></p>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Novo Medicamento
            </Button>
          </TabsContent>

          {/* Reprodução Tab */}
          <TabsContent value="reproducao" className="space-y-4">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b">
                  <tr>
                    <th className="text-left py-3 px-4">Fêmea</th>
                    <th className="text-left py-3 px-4">Macho</th>
                    <th className="text-left py-3 px-4">Data</th>
                    <th className="text-left py-3 px-4">Status</th>
                    <th className="text-left py-3 px-4">Ação</th>
                  </tr>
                </thead>
                <tbody>
                  {reproducao.map((rep) => (
                    <tr key={rep.id} className="border-b hover:bg-muted/50">
                      <td className="py-3 px-4 font-semibold">{rep.femea}</td>
                      <td className="py-3 px-4">{rep.macho}</td>
                      <td className="py-3 px-4">{rep.data}</td>
                      <td className="py-3 px-4">
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          rep.status === 'Confirmada' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                        }`}>
                          {rep.status}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <Button variant="ghost" size="sm">Editar</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Novo Registro
            </Button>
          </TabsContent>

          {/* Alertas Tab */}
          <TabsContent value="alertas" className="space-y-4">
            {alertas.length > 0 ? (
              <div className="space-y-3">
                {alertas.map((alerta) => (
                  <Card key={alerta.id} className="p-4 border-l-4 border-yellow-500 bg-yellow-50">
                    <div className="flex items-start gap-4">
                      <AlertCircle className="h-6 w-6 text-yellow-600 mt-1" />
                      <div className="flex-1">
                        <p className="font-semibold">Animal {alerta.animal}</p>
                        <p className="text-sm text-muted-foreground">{alerta.tipo}</p>
                        <p className="text-sm mt-2">{alerta.mensagem}</p>
                      </div>
                      <Button variant="outline" size="sm">Ação</Button>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="p-12 text-center">
                <Heart className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <p className="text-muted-foreground">Todos os animais estão saudáveis</p>
              </Card>
            )}
          </TabsContent>
        </Tabs>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Total de Animais</p>
            <p className="text-2xl font-bold mt-2">3</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Saudáveis</p>
            <p className="text-2xl font-bold mt-2 text-green-600">2</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Em Observação</p>
            <p className="text-2xl font-bold mt-2 text-yellow-600">1</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Alertas Ativos</p>
            <p className="text-2xl font-bold mt-2 text-red-600">2</p>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
