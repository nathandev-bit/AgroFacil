import { useAuth } from '@/_core/hooks/useAuth';
import DashboardLayout from '@/components/DashboardLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Plus,
  Wrench,
  Fuel,
  AlertCircle,
  Calendar,
  BarChart3,
} from 'lucide-react';

/**
 * Controle de Máquinas
 * Gestão de tratores, horas de uso, combustível e manutenções
 */
export default function ControleMaquinas() {
  const { user } = useAuth();

  const maquinas = [
    { id: 1, nome: 'Trator John Deere 5090', placa: 'ABC-1234', ano: 2018, horas: 2450, status: 'Operacional' },
    { id: 2, nome: 'Trator Massey Ferguson 290', placa: 'DEF-5678', ano: 2015, horas: 3200, status: 'Operacional' },
    { id: 3, nome: 'Colhedora Claas Lexion', placa: 'GHI-9012', ano: 2019, horas: 1800, status: 'Manutenção' },
  ];

  const combustivel = [
    { id: 1, maquina: 'Trator John Deere 5090', data: '2026-05-25', litros: 150, preco: 6.50, total: 975.00 },
    { id: 2, maquina: 'Trator Massey Ferguson 290', data: '2026-05-24', litros: 120, preco: 6.50, total: 780.00 },
    { id: 3, maquina: 'Colhedora Claas Lexion', data: '2026-05-23', litros: 200, preco: 6.50, total: 1300.00 },
  ];

  const manutencoes = [
    { id: 1, maquina: 'Trator John Deere 5090', tipo: 'Troca de Óleo', data: '2026-05-20', valor: 350.00, status: 'Concluída' },
    { id: 2, maquina: 'Trator Massey Ferguson 290', tipo: 'Revisão Geral', data: '2026-05-15', valor: 1200.00, status: 'Concluída' },
    { id: 3, maquina: 'Colhedora Claas Lexion', tipo: 'Reparo Corrente', data: '2026-05-25', valor: 800.00, status: 'Pendente' },
  ];

  const horasUso = [
    { id: 1, maquina: 'Trator John Deere 5090', mes: 'Maio', horas: 180, custo: 450.00 },
    { id: 2, maquina: 'Trator Massey Ferguson 290', mes: 'Maio', horas: 160, custo: 400.00 },
    { id: 3, maquina: 'Colhedora Claas Lexion', mes: 'Maio', horas: 120, custo: 300.00 },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Controle de Máquinas</h1>
            <p className="text-muted-foreground mt-2">
              Tratores, horas de uso, combustível e manutenções
            </p>
          </div>
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Novo Equipamento
          </Button>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="maquinas" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="maquinas">Máquinas</TabsTrigger>
            <TabsTrigger value="combustivel">Combustível</TabsTrigger>
            <TabsTrigger value="manutencoes">Manutenções</TabsTrigger>
            <TabsTrigger value="horas">Horas de Uso</TabsTrigger>
          </TabsList>

          {/* Máquinas Tab */}
          <TabsContent value="maquinas" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {maquinas.map((maq) => (
                <Card key={maq.id} className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <Wrench className="h-8 w-8 text-blue-600" />
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      maq.status === 'Operacional' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                    }`}>
                      {maq.status}
                    </span>
                  </div>
                  <h3 className="font-semibold text-lg mb-3">{maq.nome}</h3>
                  <div className="space-y-2 text-sm text-muted-foreground mb-4">
                    <p>Placa: <strong>{maq.placa}</strong></p>
                    <p>Ano: <strong>{maq.ano}</strong></p>
                    <p>Horas: <strong>{maq.horas}h</strong></p>
                  </div>
                  <Button variant="outline" className="w-full">Detalhes</Button>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Combustível Tab */}
          <TabsContent value="combustivel" className="space-y-4">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b">
                  <tr>
                    <th className="text-left py-3 px-4">Máquina</th>
                    <th className="text-left py-3 px-4">Data</th>
                    <th className="text-left py-3 px-4">Litros</th>
                    <th className="text-left py-3 px-4">Preço/L</th>
                    <th className="text-left py-3 px-4">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {combustivel.map((comb) => (
                    <tr key={comb.id} className="border-b hover:bg-muted/50">
                      <td className="py-3 px-4 font-semibold">{comb.maquina}</td>
                      <td className="py-3 px-4">{comb.data}</td>
                      <td className="py-3 px-4">{comb.litros} L</td>
                      <td className="py-3 px-4">R$ {comb.preco.toFixed(2)}</td>
                      <td className="py-3 px-4 font-semibold">R$ {comb.total.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Novo Abastecimento
            </Button>
          </TabsContent>

          {/* Manutenções Tab */}
          <TabsContent value="manutencoes" className="space-y-4">
            <div className="space-y-3">
              {manutencoes.map((manut) => (
                <Card key={manut.id} className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4">
                      <AlertCircle className="h-6 w-6 text-blue-600 mt-1" />
                      <div>
                        <p className="font-semibold">{manut.maquina}</p>
                        <p className="text-sm text-muted-foreground">{manut.tipo}</p>
                        <p className="text-sm mt-2">Data: <strong>{manut.data}</strong></p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">R$ {manut.valor.toFixed(2)}</p>
                      <span className={`text-xs px-2 py-1 rounded-full block mt-2 ${
                        manut.status === 'Concluída' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                      }`}>
                        {manut.status}
                      </span>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Nova Manutenção
            </Button>
          </TabsContent>

          {/* Horas de Uso Tab */}
          <TabsContent value="horas" className="space-y-4">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b">
                  <tr>
                    <th className="text-left py-3 px-4">Máquina</th>
                    <th className="text-left py-3 px-4">Mês</th>
                    <th className="text-left py-3 px-4">Horas</th>
                    <th className="text-left py-3 px-4">Custo/Hora</th>
                    <th className="text-left py-3 px-4">Custo Total</th>
                  </tr>
                </thead>
                <tbody>
                  {horasUso.map((hora) => (
                    <tr key={hora.id} className="border-b hover:bg-muted/50">
                      <td className="py-3 px-4 font-semibold">{hora.maquina}</td>
                      <td className="py-3 px-4">{hora.mes}</td>
                      <td className="py-3 px-4">{hora.horas}h</td>
                      <td className="py-3 px-4">R$ {(hora.custo / hora.horas).toFixed(2)}</td>
                      <td className="py-3 px-4 font-semibold">R$ {hora.custo.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </TabsContent>
        </Tabs>

        {/* Resumo */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Total de Máquinas</p>
            <p className="text-2xl font-bold mt-2">3</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Operacionais</p>
            <p className="text-2xl font-bold mt-2 text-green-600">2</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Custo Combustível (Mês)</p>
            <p className="text-2xl font-bold mt-2">R$ 3.055</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Manutenções Pendentes</p>
            <p className="text-2xl font-bold mt-2 text-yellow-600">1</p>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
