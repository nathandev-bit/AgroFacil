import { useAuth } from '@/_core/hooks/useAuth';
import DashboardLayout from '@/components/DashboardLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Plus,
  FileText,
  Download,
  Calendar,
  BarChart3,
} from 'lucide-react';

/**
 * Relatórios
 * Geração de relatórios em PDF e Excel com logo AgroFácil e assinatura digital
 */
export default function Relatorios() {
  const { user } = useAuth();

  const relatoriosDisp = [
    { id: 1, titulo: 'Relatório Financeiro Mensal', tipo: 'PDF', data: '2026-05-31', status: 'Disponível' },
    { id: 2, titulo: 'Análise de Produção', tipo: 'Excel', data: '2026-05-30', status: 'Disponível' },
    { id: 3, titulo: 'Gestão de Rebanho', tipo: 'PDF', data: '2026-05-29', status: 'Disponível' },
    { id: 4, titulo: 'Controle de Estoque', tipo: 'Excel', data: '2026-05-28', status: 'Disponível' },
  ];

  const relatoriosAgendados = [
    { id: 1, titulo: 'Relatório Trimestral', tipo: 'PDF', data: '2026-06-30', status: 'Agendado' },
    { id: 2, titulo: 'Análise de Custos', tipo: 'Excel', data: '2026-06-15', status: 'Agendado' },
  ];

  const templates = [
    { id: 1, nome: 'Financeiro Mensal', descricao: 'Receitas, despesas e fluxo de caixa' },
    { id: 2, nome: 'Produção Agrícola', descricao: 'Culturas, talhões e produtividade' },
    { id: 3, nome: 'Gestão Pecuária', descricao: 'Animais, saúde e reprodução' },
    { id: 4, nome: 'Análise de Estoque', descricao: 'Inventário e movimentações' },
    { id: 5, nome: 'Recursos Humanos', descricao: 'Folha de pagamento e atividades' },
    { id: 6, nome: 'Mercado Agro', descricao: 'Cotações e tendências de preços' },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Relatórios</h1>
            <p className="text-muted-foreground mt-2">
              Geração de relatórios em PDF e Excel com logo AgroFácil e assinatura digital
            </p>
          </div>
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Novo Relatório
          </Button>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="disponiveis" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="disponiveis">Disponíveis</TabsTrigger>
            <TabsTrigger value="agendados">Agendados</TabsTrigger>
            <TabsTrigger value="templates">Templates</TabsTrigger>
          </TabsList>

          {/* Disponíveis Tab */}
          <TabsContent value="disponiveis" className="space-y-4">
            <div className="space-y-3">
              {relatoriosDisp.map((rel) => (
                <Card key={rel.id} className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <FileText className="h-6 w-6 text-blue-600" />
                      <div>
                        <p className="font-semibold">{rel.titulo}</p>
                        <p className="text-sm text-muted-foreground">{rel.data}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-700">
                        {rel.tipo}
                      </span>
                      <Button variant="outline" size="sm" className="gap-1">
                        <Download className="h-4 w-4" />
                        Download
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Agendados Tab */}
          <TabsContent value="agendados" className="space-y-4">
            <div className="space-y-3">
              {relatoriosAgendados.map((rel) => (
                <Card key={rel.id} className="p-4 border-l-4 border-yellow-500 bg-yellow-50">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <Calendar className="h-6 w-6 text-yellow-600" />
                      <div>
                        <p className="font-semibold">{rel.titulo}</p>
                        <p className="text-sm text-muted-foreground">Agendado para: {rel.data}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs px-2 py-1 rounded-full bg-yellow-100 text-yellow-700">
                        {rel.tipo}
                      </span>
                      <Button variant="outline" size="sm">Editar</Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Agendar Relatório
            </Button>
          </TabsContent>

          {/* Templates Tab */}
          <TabsContent value="templates" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {templates.map((template) => (
                <Card key={template.id} className="p-6 hover:shadow-lg transition-shadow">
                  <BarChart3 className="h-8 w-8 text-primary mb-3" />
                  <h3 className="font-semibold text-lg mb-2">{template.nome}</h3>
                  <p className="text-sm text-muted-foreground mb-4">{template.descricao}</p>
                  <Button className="w-full">Usar Template</Button>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Recursos */}
        <Card className="p-6 bg-gradient-to-br from-blue-50 to-cyan-50">
          <h3 className="text-lg font-semibold mb-4">Recursos de Relatórios</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <p className="font-semibold mb-2">📄 Logo AgroFácil</p>
              <p className="text-sm text-muted-foreground">Todos os relatórios incluem logo oficial</p>
            </div>
            <div>
              <p className="font-semibold mb-2">✍️ Assinatura Digital</p>
              <p className="text-sm text-muted-foreground">Autenticação e validade legal</p>
            </div>
            <div>
              <p className="font-semibold mb-2">📊 Gráficos Avançados</p>
              <p className="text-sm text-muted-foreground">Visualizações profissionais</p>
            </div>
          </div>
        </Card>

        {/* Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Relatórios Gerados</p>
            <p className="text-2xl font-bold mt-2">24</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Este Mês</p>
            <p className="text-2xl font-bold mt-2">4</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Agendados</p>
            <p className="text-2xl font-bold mt-2">2</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Templates</p>
            <p className="text-2xl font-bold mt-2">6</p>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
