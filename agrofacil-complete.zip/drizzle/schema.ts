import {
  int,
  varchar,
  text,
  timestamp,
  mysqlEnum,
  mysqlTable,
  decimal,
  boolean,
  json,
  index,
} from "drizzle-orm/mysql-core";

/**
 * AgroFácil Database Schema
 * Complete agricultural management platform with AI
 * 
 * Design principles:
 * - Timestamps stored as UTC
 * - Soft deletes where appropriate
 * - Proper indexing for performance
 * - Role-based access control
 */

// ==================== USERS & AUTHENTICATION ====================

export const users = mysqlTable(
  "users",
  {
    id: int("id").autoincrement().primaryKey(),
    openId: varchar("openId", { length: 255 }).notNull().unique(),
    email: varchar("email", { length: 255 }).notNull().unique(),
    name: varchar("name", { length: 255 }).notNull(),
    avatar: text("avatar"),
    
    // Authentication
    loginMethod: mysqlEnum("loginMethod", ["oauth", "email"]).default("oauth"),
    emailVerified: boolean("emailVerified").default(false),
    
    // 2FA
    twoFactorEnabled: boolean("twoFactorEnabled").default(false),
    twoFactorSecret: varchar("twoFactorSecret", { length: 255 }),
    
    // Subscription
    role: mysqlEnum("role", ["user", "admin"]).default("user"),
    subscriptionId: int("subscriptionId"),
    
    // Timestamps
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
    lastLoginAt: timestamp("lastLoginAt"),
  },
  (table) => ({
    emailIdx: index("email_idx").on(table.email),
    openIdIdx: index("openId_idx").on(table.openId),
    roleIdx: index("role_idx").on(table.role),
  })
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ==================== SUBSCRIPTIONS & PLANS ====================

export const plans = mysqlTable(
  "plans",
  {
    id: int("id").autoincrement().primaryKey(),
    name: varchar("name", { length: 100 }).notNull(),
    slug: varchar("slug", { length: 50 }).notNull().unique(),
    priceUsd: decimal("priceUsd", { precision: 10, scale: 2 }).notNull(),
    analysisLimit: int("analysisLimit").notNull(), // -1 for unlimited
    features: json("features").notNull(), // JSON array of feature strings
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  }
);

export type Plan = typeof plans.$inferSelect;
export type InsertPlan = typeof plans.$inferInsert;

export const subscriptions = mysqlTable(
  "subscriptions",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    planId: int("planId").notNull(),
    stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }),
    status: mysqlEnum("status", ["active", "cancelled", "past_due", "paused"]).default("active"),
    currentPeriodStart: timestamp("currentPeriodStart"),
    currentPeriodEnd: timestamp("currentPeriodEnd"),
    cancelledAt: timestamp("cancelledAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    userIdIdx: index("subscription_userId_idx").on(table.userId),
    statusIdx: index("subscription_status_idx").on(table.status),
  })
);

export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = typeof subscriptions.$inferInsert;

// ==================== FARMS & PROPERTIES ====================

export const farms = mysqlTable(
  "farms",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    name: varchar("name", { length: 255 }).notNull(),
    totalAreaHectares: decimal("totalAreaHectares", { precision: 10, scale: 2 }),
    latitude: decimal("latitude", { precision: 10, scale: 6 }),
    longitude: decimal("longitude", { precision: 10, scale: 6 }),
    address: text("address"),
    city: varchar("city", { length: 100 }),
    state: varchar("state", { length: 50 }),
    country: varchar("country", { length: 100 }).default("Brasil"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    userIdIdx: index("farm_userId_idx").on(table.userId),
  })
);

export type Farm = typeof farms.$inferSelect;
export type InsertFarm = typeof farms.$inferInsert;

// ==================== AGRICULTURE ====================

export const crops = mysqlTable(
  "crops",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    farmId: int("farmId").notNull(),
    type: mysqlEnum("type", [
      "SOJA",
      "MILHO",
      "ARROZ",
      "FEIJAO",
      "CAFE",
      "ALGODAO",
      "TRIGO",
      "CANA",
      "HORTALICA",
      "FRUTA",
      "OUTRO",
    ]).notNull(),
    variety: varchar("variety", { length: 255 }),
    areaHectares: decimal("areaHectares", { precision: 10, scale: 2 }).notNull(),
    plantingDate: timestamp("plantingDate").notNull(),
    expectedHarvestDate: timestamp("expectedHarvestDate"),
    harvestDate: timestamp("harvestDate"),
    status: mysqlEnum("status", [
      "PLANNED",
      "PLANTED",
      "GROWING",
      "FLOWERING",
      "MATURING",
      "HARVESTING",
      "HARVESTED",
    ]).default("PLANTED"),
    estimatedYieldTonnes: decimal("estimatedYieldTonnes", { precision: 10, scale: 2 }),
    actualYieldTonnes: decimal("actualYieldTonnes", { precision: 10, scale: 2 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    userIdIdx: index("crop_userId_idx").on(table.userId),
    farmIdIdx: index("crop_farmId_idx").on(table.farmId),
    typeIdx: index("crop_type_idx").on(table.type),
  })
);

export type Crop = typeof crops.$inferSelect;
export type InsertCrop = typeof crops.$inferInsert;

export const soilAnalyses = mysqlTable(
  "soilAnalyses",
  {
    id: int("id").autoincrement().primaryKey(),
    farmId: int("farmId").notNull(),
    sampleDate: timestamp("sampleDate").notNull(),
    sampleLocation: varchar("sampleLocation", { length: 255 }),
    latitude: decimal("latitude", { precision: 10, scale: 6 }),
    longitude: decimal("longitude", { precision: 10, scale: 6 }),
    
    // Soil parameters
    ph: decimal("ph", { precision: 4, scale: 2 }),
    nitrogen: decimal("nitrogen", { precision: 8, scale: 2 }), // mg/kg
    phosphorus: decimal("phosphorus", { precision: 8, scale: 2 }), // mg/kg
    potassium: decimal("potassium", { precision: 8, scale: 2 }), // mg/kg
    calcium: decimal("calcium", { precision: 8, scale: 2 }), // cmolc/dm³
    magnesium: decimal("magnesium", { precision: 8, scale: 2 }), // cmolc/dm³
    sulfur: decimal("sulfur", { precision: 8, scale: 2 }), // mg/kg
    organicMatter: decimal("organicMatter", { precision: 5, scale: 2 }), // %
    cec: decimal("cec", { precision: 8, scale: 2 }), // capacidade de troca catiônica
    baseSaturation: decimal("baseSaturation", { precision: 5, scale: 2 }), // %
    
    // AI results
    diagnosis: json("diagnosis"),
    recommendations: json("recommendations"),
    reportUrl: text("reportUrl"),
    
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    farmIdIdx: index("soilAnalysis_farmId_idx").on(table.farmId),
  })
);

export type SoilAnalysis = typeof soilAnalyses.$inferSelect;
export type InsertSoilAnalysis = typeof soilAnalyses.$inferInsert;

// ==================== LIVESTOCK ====================

export const livestock = mysqlTable(
  "livestock",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    farmId: int("farmId").notNull(),
    identifier: varchar("identifier", { length: 100 }).notNull(), // brinco, chip, nome
    species: mysqlEnum("species", [
      "BOVINO",
      "SUINO",
      "OVINO",
      "CAPRINO",
      "EQUINO",
      "AVE",
      "PEIXE",
      "OUTRO",
    ]).notNull(),
    breed: varchar("breed", { length: 100 }),
    gender: mysqlEnum("gender", ["MALE", "FEMALE"]).notNull(),
    birthDate: timestamp("birthDate"),
    weight: decimal("weight", { precision: 8, scale: 2 }), // kg
    status: mysqlEnum("status", ["ACTIVE", "SOLD", "DECEASED", "TRANSFERRED"]).default("ACTIVE"),
    acquisitionDate: timestamp("acquisitionDate"),
    acquisitionCost: decimal("acquisitionCost", { precision: 10, scale: 2 }),
    motherId: int("motherId"),
    fatherId: int("fatherId"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    userIdIdx: index("livestock_userId_idx").on(table.userId),
    farmIdIdx: index("livestock_farmId_idx").on(table.farmId),
    identifierIdx: index("livestock_identifier_idx").on(table.identifier),
  })
);

export type Livestock = typeof livestock.$inferSelect;
export type InsertLivestock = typeof livestock.$inferInsert;

export const vaccinations = mysqlTable(
  "vaccinations",
  {
    id: int("id").autoincrement().primaryKey(),
    livestockId: int("livestockId").notNull(),
    vaccineName: varchar("vaccineName", { length: 255 }).notNull(),
    batchNumber: varchar("batchNumber", { length: 100 }),
    appliedAt: timestamp("appliedAt").notNull(),
    nextDoseAt: timestamp("nextDoseAt"),
    veterinarian: varchar("veterinarian", { length: 255 }),
    notes: text("notes"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    livestockIdIdx: index("vaccination_livestockId_idx").on(table.livestockId),
    nextDoseIdx: index("vaccination_nextDose_idx").on(table.nextDoseAt),
  })
);

export type Vaccination = typeof vaccinations.$inferSelect;
export type InsertVaccination = typeof vaccinations.$inferInsert;

export const healthRecords = mysqlTable(
  "healthRecords",
  {
    id: int("id").autoincrement().primaryKey(),
    livestockId: int("livestockId").notNull(),
    recordDate: timestamp("recordDate").notNull(),
    type: mysqlEnum("type", ["CONSULTATION", "TREATMENT", "SURGERY", "EXAM", "OBSERVATION"]).notNull(),
    description: text("description").notNull(),
    treatment: text("treatment"),
    medication: text("medication"),
    veterinarian: varchar("veterinarian", { length: 255 }),
    cost: decimal("cost", { precision: 10, scale: 2 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    livestockIdIdx: index("healthRecord_livestockId_idx").on(table.livestockId),
  })
);

export type HealthRecord = typeof healthRecords.$inferSelect;
export type InsertHealthRecord = typeof healthRecords.$inferInsert;

// ==================== DIAGNOSTICS ====================

export const diagnostics = mysqlTable(
  "diagnostics",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    type: mysqlEnum("type", [
      "PLANTDISEASE",
      "PLANTPEST",
      "PLANTDEFICIENCY",
      "ANIMALHEALTH",
      "ANIMALBEHAVIOR",
    ]).notNull(),
    cropId: int("cropId"),
    livestockId: int("livestockId"),
    imageUrl: text("imageUrl"),
    videoUrl: text("videoUrl"),
    result: json("result").notNull(),
    confidence: decimal("confidence", { precision: 5, scale: 2 }), // 0-100
    riskLevel: mysqlEnum("riskLevel", ["LOW", "MEDIUM", "HIGH", "CRITICAL"]),
    recommendations: json("recommendations"),
    reportUrl: text("reportUrl"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    userIdIdx: index("diagnostic_userId_idx").on(table.userId),
    typeIdx: index("diagnostic_type_idx").on(table.type),
  })
);

export type Diagnostic = typeof diagnostics.$inferSelect;
export type InsertDiagnostic = typeof diagnostics.$inferInsert;

// ==================== AGROIA CONVERSATIONS ====================

export const conversations = mysqlTable(
  "conversations",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    title: varchar("title", { length: 255 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    userIdIdx: index("conversation_userId_idx").on(table.userId),
  })
);

export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = typeof conversations.$inferInsert;

export const messages = mysqlTable(
  "messages",
  {
    id: int("id").autoincrement().primaryKey(),
    conversationId: int("conversationId").notNull(),
    role: mysqlEnum("role", ["USER", "ASSISTANT", "SYSTEM"]).notNull(),
    content: text("content").notNull(),
    attachments: json("attachments"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    conversationIdIdx: index("message_conversationId_idx").on(table.conversationId),
  })
);

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

// ==================== FINANCIAL ====================

export const finances = mysqlTable(
  "finances",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    cropId: int("cropId"),
    type: mysqlEnum("type", ["INCOME", "EXPENSE"]).notNull(),
    category: varchar("category", { length: 100 }).notNull(),
    description: text("description"),
    amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
    date: timestamp("date").notNull(),
    dueDate: timestamp("dueDate"),
    paidAt: timestamp("paidAt"),
    status: mysqlEnum("status", ["PENDING", "PAID", "OVERDUE", "CANCELLED"]).default("PENDING"),
    attachmentUrl: text("attachmentUrl"),
    notes: text("notes"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    userIdIdx: index("finance_userId_idx").on(table.userId),
    typeIdx: index("finance_type_idx").on(table.type),
    dateIdx: index("finance_date_idx").on(table.date),
  })
);

export type Finance = typeof finances.$inferSelect;
export type InsertFinance = typeof finances.$inferInsert;

// ==================== INVENTORY ====================

export const inventoryItems = mysqlTable(
  "inventoryItems",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    name: varchar("name", { length: 255 }).notNull(),
    category: mysqlEnum("category", [
      "FERTILIZER",
      "PESTICIDE",
      "HERBICIDE",
      "SEED",
      "FEED",
      "MEDICATION",
      "FUEL",
      "TOOL",
      "EQUIPMENT",
      "OTHER",
    ]).notNull(),
    quantity: decimal("quantity", { precision: 12, scale: 2 }).notNull(),
    unit: varchar("unit", { length: 50 }).notNull(),
    minQuantity: decimal("minQuantity", { precision: 12, scale: 2 }),
    unitCost: decimal("unitCost", { precision: 10, scale: 2 }),
    supplier: varchar("supplier", { length: 255 }),
    location: varchar("location", { length: 255 }),
    expiryDate: timestamp("expiryDate"),
    batchNumber: varchar("batchNumber", { length: 100 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    userIdIdx: index("inventoryItem_userId_idx").on(table.userId),
    categoryIdx: index("inventoryItem_category_idx").on(table.category),
  })
);

export type InventoryItem = typeof inventoryItems.$inferSelect;
export type InsertInventoryItem = typeof inventoryItems.$inferInsert;

export const inventoryMovements = mysqlTable(
  "inventoryMovements",
  {
    id: int("id").autoincrement().primaryKey(),
    itemId: int("itemId").notNull(),
    type: mysqlEnum("type", ["IN", "OUT", "ADJUSTMENT"]).notNull(),
    quantity: decimal("quantity", { precision: 12, scale: 2 }).notNull(),
    reason: text("reason"),
    performedBy: varchar("performedBy", { length: 255 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    itemIdIdx: index("inventoryMovement_itemId_idx").on(table.itemId),
  })
);

export type InventoryMovement = typeof inventoryMovements.$inferSelect;
export type InsertInventoryMovement = typeof inventoryMovements.$inferInsert;

// ==================== MACHINERY ====================

export const machinery = mysqlTable(
  "machinery",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    farmId: int("farmId").notNull(),
    name: varchar("name", { length: 255 }).notNull(),
    type: mysqlEnum("type", [
      "TRACTOR",
      "HARVESTER",
      "SPRAYER",
      "PLANTER",
      "TRUCK",
      "IMPLEMENT",
      "IRRIGATION",
      "OTHER",
    ]).notNull(),
    brand: varchar("brand", { length: 100 }),
    model: varchar("model", { length: 100 }),
    year: int("year"),
    serialNumber: varchar("serialNumber", { length: 255 }),
    purchaseDate: timestamp("purchaseDate"),
    purchaseCost: decimal("purchaseCost", { precision: 10, scale: 2 }),
    currentValue: decimal("currentValue", { precision: 10, scale: 2 }),
    status: mysqlEnum("status", ["ACTIVE", "MAINTENANCE", "INACTIVE", "SOLD"]).default("ACTIVE"),
    hoursWorked: decimal("hoursWorked", { precision: 10, scale: 2 }).default("0"),
    fuelConsumed: decimal("fuelConsumed", { precision: 12, scale: 2 }).default("0"), // litros
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    userIdIdx: index("machinery_userId_idx").on(table.userId),
    farmIdIdx: index("machinery_farmId_idx").on(table.farmId),
  })
);

export type Machinery = typeof machinery.$inferSelect;
export type InsertMachinery = typeof machinery.$inferInsert;

export const maintenances = mysqlTable(
  "maintenances",
  {
    id: int("id").autoincrement().primaryKey(),
    machineryId: int("machineryId").notNull(),
    type: mysqlEnum("type", ["PREVENTIVE", "CORRECTIVE", "INSPECTION"]).notNull(),
    description: text("description").notNull(),
    cost: decimal("cost", { precision: 10, scale: 2 }),
    performedAt: timestamp("performedAt").notNull(),
    nextDueAt: timestamp("nextDueAt"),
    performedBy: varchar("performedBy", { length: 255 }),
    notes: text("notes"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    machineryIdIdx: index("maintenance_machineryId_idx").on(table.machineryId),
    nextDueIdx: index("maintenance_nextDue_idx").on(table.nextDueAt),
  })
);

export type Maintenance = typeof maintenances.$inferSelect;
export type InsertMaintenance = typeof maintenances.$inferInsert;

export const fuelRecords = mysqlTable(
  "fuelRecords",
  {
    id: int("id").autoincrement().primaryKey(),
    machineryId: int("machineryId").notNull(),
    liters: decimal("liters", { precision: 10, scale: 2 }).notNull(),
    costPerLiter: decimal("costPerLiter", { precision: 8, scale: 2 }),
    totalCost: decimal("totalCost", { precision: 10, scale: 2 }),
    odometer: decimal("odometer", { precision: 10, scale: 2 }),
    hoursWorked: decimal("hoursWorked", { precision: 10, scale: 2 }),
    fueledAt: timestamp("fueledAt").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    machineryIdIdx: index("fuelRecord_machineryId_idx").on(table.machineryId),
  })
);

export type FuelRecord = typeof fuelRecords.$inferSelect;
export type InsertFuelRecord = typeof fuelRecords.$inferInsert;

// ==================== EMPLOYEES ====================

export const employees = mysqlTable(
  "employees",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    farmId: int("farmId").notNull(),
    name: varchar("name", { length: 255 }).notNull(),
    cpf: varchar("cpf", { length: 20 }),
    phone: varchar("phone", { length: 20 }),
    email: varchar("email", { length: 255 }),
    role: varchar("role", { length: 100 }).notNull(),
    salary: decimal("salary", { precision: 10, scale: 2 }),
    hireDate: timestamp("hireDate").notNull(),
    terminationDate: timestamp("terminationDate"),
    status: mysqlEnum("status", ["ACTIVE", "ONLEAVE", "TERMINATED"]).default("ACTIVE"),
    address: text("address"),
    emergencyContact: varchar("emergencyContact", { length: 255 }),
    emergencyPhone: varchar("emergencyPhone", { length: 20 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    userIdIdx: index("employee_userId_idx").on(table.userId),
    farmIdIdx: index("employee_farmId_idx").on(table.farmId),
  })
);

export type Employee = typeof employees.$inferSelect;
export type InsertEmployee = typeof employees.$inferInsert;

export const activities = mysqlTable(
  "activities",
  {
    id: int("id").autoincrement().primaryKey(),
    employeeId: int("employeeId").notNull(),
    date: timestamp("date").notNull(),
    description: text("description").notNull(),
    hoursWorked: decimal("hoursWorked", { precision: 8, scale: 2 }),
    notes: text("notes"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    employeeIdIdx: index("activity_employeeId_idx").on(table.employeeId),
    dateIdx: index("activity_date_idx").on(table.date),
  })
);

export type Activity = typeof activities.$inferSelect;
export type InsertActivity = typeof activities.$inferInsert;

// ==================== ALERTS ====================

export const alerts = mysqlTable(
  "alerts",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    type: mysqlEnum("type", [
      "CLIMATE",
      "PEST",
      "DISEASE",
      "VACCINE",
      "INVENTORY",
      "FINANCE",
      "MAINTENANCE",
      "GENERAL",
    ]).notNull(),
    severity: mysqlEnum("severity", ["INFO", "WARNING", "CRITICAL"]).notNull(),
    title: varchar("title", { length: 255 }).notNull(),
    message: text("message").notNull(),
    data: json("data"),
    read: boolean("read").default(false),
    readAt: timestamp("readAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    userIdIdx: index("alert_userId_idx").on(table.userId),
    typeIdx: index("alert_type_idx").on(table.type),
  })
);

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = typeof alerts.$inferInsert;

// ==================== REPORTS ====================

export const reports = mysqlTable(
  "reports",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    type: mysqlEnum("type", [
      "DIAGNOSTIC",
      "FINANCIAL",
      "PRODUCTION",
      "INVENTORY",
      "LIVESTOCK",
      "GENERAL",
    ]).notNull(),
    title: varchar("title", { length: 255 }).notNull(),
    data: json("data").notNull(),
    fileUrl: text("fileUrl"),
    format: mysqlEnum("format", ["PDF", "EXCEL", "JSON"]).default("PDF"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    userIdIdx: index("report_userId_idx").on(table.userId),
    typeIdx: index("report_type_idx").on(table.type),
  })
);

export type Report = typeof reports.$inferSelect;
export type InsertReport = typeof reports.$inferInsert;

// ==================== MARKET PRICES ====================

export const marketPrices = mysqlTable(
  "marketPrices",
  {
    id: int("id").autoincrement().primaryKey(),
    commodity: varchar("commodity", { length: 100 }).notNull(),
    pricePerUnit: decimal("pricePerUnit", { precision: 10, scale: 2 }).notNull(),
    unit: varchar("unit", { length: 50 }).notNull(),
    source: varchar("source", { length: 100 }),
    date: timestamp("date").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    commodityIdx: index("marketPrice_commodity_idx").on(table.commodity),
    dateIdx: index("marketPrice_date_idx").on(table.date),
  })
);

export type MarketPrice = typeof marketPrices.$inferSelect;
export type InsertMarketPrice = typeof marketPrices.$inferInsert;

// ==================== NETWORK ALERTS (Rede AgroFácil) ====================

export const networkAlerts = mysqlTable(
  "networkAlerts",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    type: mysqlEnum("type", ["PEST", "DISEASE", "CLIMATE", "OTHER"]).notNull(),
    title: varchar("title", { length: 255 }).notNull(),
    description: text("description").notNull(),
    latitude: decimal("latitude", { precision: 10, scale: 6 }).notNull(),
    longitude: decimal("longitude", { precision: 10, scale: 6 }).notNull(),
    radiusKm: decimal("radiusKm", { precision: 8, scale: 2 }).default("50"),
    severity: mysqlEnum("severity", ["LOW", "MEDIUM", "HIGH", "CRITICAL"]).notNull(),
    isPublic: boolean("isPublic").default(true),
    viewCount: int("viewCount").default(0),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    userIdIdx: index("networkAlert_userId_idx").on(table.userId),
    typeIdx: index("networkAlert_type_idx").on(table.type),
  })
);

export type NetworkAlert = typeof networkAlerts.$inferSelect;
export type InsertNetworkAlert = typeof networkAlerts.$inferInsert;
