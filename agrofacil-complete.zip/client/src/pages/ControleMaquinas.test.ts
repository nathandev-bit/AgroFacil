import { describe, it, expect } from 'vitest';

describe('Controle de Máquinas - Content Validation', () => {
  it('should have maquinas', () => {
    const maquinas = [
      { nome: 'Trator John Deere 5090', horas: 2450 },
      { nome: 'Trator Massey Ferguson 290', horas: 3200 },
      { nome: 'Colhedora Claas Lexion', horas: 1800 },
    ];
    expect(maquinas).toHaveLength(3);
  });

  it('should have combustivel records', () => {
    const combustivel = [
      { litros: 150, preco: 6.50 },
      { litros: 120, preco: 6.50 },
      { litros: 200, preco: 6.50 },
    ];
    expect(combustivel).toHaveLength(3);
  });

  it('should calculate combustivel total', () => {
    const combustivel = [
      { litros: 150, preco: 6.50 },
      { litros: 120, preco: 6.50 },
      { litros: 200, preco: 6.50 },
    ];
    const total = combustivel.reduce((sum, c) => sum + (c.litros * c.preco), 0);
    expect(total).toBeCloseTo(3055, 0);
  });

  it('should have manutencoes', () => {
    const manutencoes = [
      { tipo: 'Troca de Óleo', valor: 350 },
      { tipo: 'Revisão Geral', valor: 1200 },
      { tipo: 'Reparo Corrente', valor: 800 },
    ];
    expect(manutencoes).toHaveLength(3);
  });

  it('should have horas de uso', () => {
    const horas = [
      { horas: 180, custo: 450 },
      { horas: 160, custo: 400 },
      { horas: 120, custo: 300 },
    ];
    expect(horas).toHaveLength(3);
  });

  it('should calculate total horas', () => {
    const horas = [
      { horas: 180 },
      { horas: 160 },
      { horas: 120 },
    ];
    const total = horas.reduce((sum, h) => sum + h.horas, 0);
    expect(total).toBe(460);
  });
});
