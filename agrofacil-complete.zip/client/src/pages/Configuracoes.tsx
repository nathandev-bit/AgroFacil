import { useAuth } from '@/_core/hooks/useAuth';
import DashboardLayout from '@/components/DashboardLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import {
  Settings,
  Lock,
  Bell,
  User,
  LogOut,
} from 'lucide-react';

/**
 * Configurações
 * Perfil, segurança, notificações e preferências
 */
export default function Configuracoes() {
  const { user, logout } = useAuth();

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold">Configurações</h1>
          <p className="text-muted-foreground mt-2">
            Gerencie seu perfil, segurança, notificações e preferências
          </p>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="perfil" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="perfil">Perfil</TabsTrigger>
            <TabsTrigger value="seguranca">Segurança</TabsTrigger>
            <TabsTrigger value="notificacoes">Notificações</TabsTrigger>
            <TabsTrigger value="preferencias">Preferências</TabsTrigger>
          </TabsList>

          {/* Perfil Tab */}
          <TabsContent value="perfil" className="space-y-4">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Informações Pessoais</h3>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-semibold">Nome</label>
                  <p className="text-muted-foreground mt-1">{user?.name || 'Usuário'}</p>
                </div>
                <div>
                  <label className="text-sm font-semibold">Email</label>
                  <p className="text-muted-foreground mt-1">{user?.email || 'email@example.com'}</p>
                </div>
                <div>
                  <label className="text-sm font-semibold">Plano Atual</label>
                  <p className="text-muted-foreground mt-1">Professional - US$ 60/mês</p>
                </div>
                <Button variant="outline">Editar Perfil</Button>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Dados da Fazenda</h3>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-semibold">Nome da Fazenda</label>
                  <p className="text-muted-foreground mt-1">Fazenda São João</p>
                </div>
                <div>
                  <label className="text-sm font-semibold">Localização</label>
                  <p className="text-muted-foreground mt-1">Mato Grosso, Brasil</p>
                </div>
                <div>
                  <label className="text-sm font-semibold">Área Total</label>
                  <p className="text-muted-foreground mt-1">500 hectares</p>
                </div>
                <Button variant="outline">Editar Dados</Button>
              </div>
            </Card>
          </TabsContent>

          {/* Segurança Tab */}
          <TabsContent value="seguranca" className="space-y-4">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Lock className="h-5 w-5" />
                Segurança da Conta
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold">Autenticação de Dois Fatores (2FA)</p>
                    <p className="text-sm text-muted-foreground">Adicione uma camada extra de segurança</p>
                  </div>
                  <Switch defaultChecked={false} />
                </div>
                <Button variant="outline">Configurar 2FA</Button>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Alterar Senha</h3>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-semibold">Senha Atual</label>
                  <input type="password" className="w-full mt-1 px-3 py-2 border rounded-lg" />
                </div>
                <div>
                  <label className="text-sm font-semibold">Nova Senha</label>
                  <input type="password" className="w-full mt-1 px-3 py-2 border rounded-lg" />
                </div>
                <div>
                  <label className="text-sm font-semibold">Confirmar Senha</label>
                  <input type="password" className="w-full mt-1 px-3 py-2 border rounded-lg" />
                </div>
                <Button>Atualizar Senha</Button>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Sessões Ativas</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-semibold">Navegador Chrome - Windows</p>
                    <p className="text-sm text-muted-foreground">Última atividade: Agora</p>
                  </div>
                  <Button variant="outline" size="sm">Encerrar</Button>
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* Notificações Tab */}
          <TabsContent value="notificacoes" className="space-y-4">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Bell className="h-5 w-5" />
                Preferências de Notificação
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold">Alertas de Pragas</p>
                    <p className="text-sm text-muted-foreground">Notificações sobre pragas detectadas</p>
                  </div>
                  <Switch defaultChecked={true} />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold">Alertas de Clima</p>
                    <p className="text-sm text-muted-foreground">Previsão de chuva e tempestades</p>
                  </div>
                  <Switch defaultChecked={true} />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold">Alertas Financeiros</p>
                    <p className="text-sm text-muted-foreground">Movimentações e despesas</p>
                  </div>
                  <Switch defaultChecked={true} />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold">Alertas de Vacinação</p>
                    <p className="text-sm text-muted-foreground">Vacinas vencendo em breve</p>
                  </div>
                  <Switch defaultChecked={true} />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold">Newsletter</p>
                    <p className="text-sm text-muted-foreground">Dicas e notícias do agronegócio</p>
                  </div>
                  <Switch defaultChecked={false} />
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Canais de Notificação</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <p className="font-semibold">Email</p>
                  <Switch defaultChecked={true} />
                </div>
                <div className="flex items-center justify-between">
                  <p className="font-semibold">SMS</p>
                  <Switch defaultChecked={false} />
                </div>
                <div className="flex items-center justify-between">
                  <p className="font-semibold">Push Notification</p>
                  <Switch defaultChecked={true} />
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* Preferências Tab */}
          <TabsContent value="preferencias" className="space-y-4">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Preferências Gerais</h3>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-semibold">Idioma</label>
                  <select className="w-full mt-1 px-3 py-2 border rounded-lg">
                    <option>Português (Brasil)</option>
                    <option>English</option>
                    <option>Español</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-semibold">Moeda</label>
                  <select className="w-full mt-1 px-3 py-2 border rounded-lg">
                    <option>Real (R$)</option>
                    <option>Dólar (US$)</option>
                    <option>Euro (€)</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-semibold">Fuso Horário</label>
                  <select className="w-full mt-1 px-3 py-2 border rounded-lg">
                    <option>Brasília (GMT-3)</option>
                    <option>Manaus (GMT-4)</option>
                    <option>Rio Branco (GMT-5)</option>
                  </select>
                </div>
                <div className="flex items-center justify-between">
                  <p className="font-semibold">Modo Escuro</p>
                  <Switch defaultChecked={false} />
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Integrações</h3>
              <div className="space-y-3">
                <Button variant="outline" className="w-full">Conectar com Google</Button>
                <Button variant="outline" className="w-full">Conectar com Microsoft</Button>
              </div>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Logout */}
        <Card className="p-6 bg-red-50 border-red-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-semibold">Sair da Conta</p>
              <p className="text-sm text-muted-foreground">Você será desconectado de todos os dispositivos</p>
            </div>
            <Button variant="destructive" className="gap-2" onClick={() => logout?.()}>
              <LogOut className="h-4 w-4" />
              Sair
            </Button>
          </div>
        </Card>
      </div>
    </DashboardLayout>
  );
}
