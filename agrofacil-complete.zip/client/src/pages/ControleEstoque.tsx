import { useAuth } from '@/_core/hooks/useAuth';
import DashboardLayout from '@/components/DashboardLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Plus,
  Package,
  AlertTriangle,
  TrendingDown,
  Calendar,
  BarChart3,
} from 'lucide-react';

/**
 * Controle de Estoque
 * Gerenciamento de fertilizantes, defensivos, rações, medicamentos, ferramentas e equipamentos
 */
export default function ControleEstoque() {
  const { user } = useAuth();

  const fertilizantes = [
    { id: 1, nome: 'Ureia', quantidade: 500, unidade: 'kg', minimo: 100, preco: 2.50 },
    { id: 2, nome: 'Superfosfato', quantidade: 300, unidade: 'kg', minimo: 150, preco: 3.20 },
    { id: 3, nome: 'Cloreto de Potássio', quantidade: 45, unidade: 'kg', minimo: 200, preco: 2.80 },
  ];

  const defensivos = [
    { id: 1, nome: 'Inseticida A', quantidade: 120, unidade: 'L', minimo: 50, preco: 45.00 },
    { id: 2, nome: 'Fungicida B', quantidade: 80, unidade: 'L', minimo: 100, preco: 65.00 },
    { id: 3, nome: 'Herbicida C', quantidade: 200, unidade: 'L', minimo: 100, preco: 35.00 },
  ];

  const racoes = [
    { id: 1, nome: 'Ração Gado Corte', quantidade: 2000, unidade: 'kg', minimo: 500, preco: 1.20 },
    { id: 2, nome: 'Ração Gado Leite', quantidade: 1500, unidade: 'kg', minimo: 1000, preco: 1.50 },
    { id: 3, nome: 'Ração Suíno', quantidade: 800, unidade: 'kg', minimo: 500, preco: 1.80 },
  ];

  const medicamentos = [
    { id: 1, nome: 'Antibiótico Injetável', quantidade: 50, unidade: 'dose', minimo: 20, preco: 12.00 },
    { id: 2, nome: 'Vitamina Complexo', quantidade: 100, unidade: 'dose', minimo: 50, preco: 8.50 },
    { id: 3, nome: 'Antiparasitário', quantidade: 75, unidade: 'dose', minimo: 30, preco: 15.00 },
  ];

  const alertasEstoque = [
    { id: 1, item: 'Cloreto de Potássio', quantidade: 45, minimo: 200, status: 'Crítico' },
    { id: 2, item: 'Fungicida B', quantidade: 80, minimo: 100, status: 'Baixo' },
  ];

  const movimentacoes = [
    { id: 1, item: 'Ureia', tipo: 'Entrada', quantidade: 200, data: '2026-05-25', usuario: 'João' },
    { id: 2, item: 'Inseticida A', tipo: 'Saída', quantidade: 50, data: '2026-05-24', usuario: 'Maria' },
    { id: 3, item: 'Ração Gado Corte', tipo: 'Entrada', quantidade: 500, data: '2026-05-23', usuario: 'Pedro' },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Controle de Estoque</h1>
            <p className="text-muted-foreground mt-2">
              Fertilizantes, defensivos, rações, medicamentos, ferramentas e equipamentos
            </p>
          </div>
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Novo Item
          </Button>
        </div>

        {/* Alertas */}
        {alertasEstoque.length > 0 && (
          <div className="space-y-2">
            {alertasEstoque.map((alerta) => (
              <Card key={alerta.id} className={`p-4 border-l-4 ${
                alerta.status === 'Crítico' ? 'border-red-500 bg-red-50' : 'border-yellow-500 bg-yellow-50'
              }`}>
                <div className="flex items-center gap-3">
                  <AlertTriangle className={`h-5 w-5 ${
                    alerta.status === 'Crítico' ? 'text-red-600' : 'text-yellow-600'
                  }`} />
                  <div className="flex-1">
                    <p className="font-semibold">{alerta.item}</p>
                    <p className="text-sm text-muted-foreground">
                      Quantidade: {alerta.quantidade} (Mínimo: {alerta.minimo})
                    </p>
                  </div>
                  <Button variant="outline" size="sm">Comprar</Button>
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* Main Content */}
        <Tabs defaultValue="fertilizantes" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="fertilizantes">Fertilizantes</TabsTrigger>
            <TabsTrigger value="defensivos">Defensivos</TabsTrigger>
            <TabsTrigger value="racoes">Rações</TabsTrigger>
            <TabsTrigger value="medicamentos">Medicamentos</TabsTrigger>
            <TabsTrigger value="movimentacoes">Movimentações</TabsTrigger>
          </TabsList>

          {/* Fertilizantes Tab */}
          <TabsContent value="fertilizantes" className="space-y-4">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b">
                  <tr>
                    <th className="text-left py-3 px-4">Item</th>
                    <th className="text-left py-3 px-4">Quantidade</th>
                    <th className="text-left py-3 px-4">Mínimo</th>
                    <th className="text-left py-3 px-4">Preço Unit.</th>
                    <th className="text-left py-3 px-4">Valor Total</th>
                    <th className="text-left py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {fertilizantes.map((fert) => {
                    const status = fert.quantidade < fert.minimo ? 'Baixo' : 'OK';
                    return (
                      <tr key={fert.id} className="border-b hover:bg-muted/50">
                        <td className="py-3 px-4 font-semibold">{fert.nome}</td>
                        <td className="py-3 px-4">{fert.quantidade} {fert.unidade}</td>
                        <td className="py-3 px-4">{fert.minimo} {fert.unidade}</td>
                        <td className="py-3 px-4">R$ {fert.preco.toFixed(2)}</td>
                        <td className="py-3 px-4">R$ {(fert.quantidade * fert.preco).toFixed(2)}</td>
                        <td className="py-3 px-4">
                          <span className={`text-xs px-2 py-1 rounded-full ${
                            status === 'OK' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                          }`}>
                            {status}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </TabsContent>

          {/* Defensivos Tab */}
          <TabsContent value="defensivos" className="space-y-4">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b">
                  <tr>
                    <th className="text-left py-3 px-4">Item</th>
                    <th className="text-left py-3 px-4">Quantidade</th>
                    <th className="text-left py-3 px-4">Mínimo</th>
                    <th className="text-left py-3 px-4">Preço Unit.</th>
                    <th className="text-left py-3 px-4">Valor Total</th>
                    <th className="text-left py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {defensivos.map((def) => {
                    const status = def.quantidade < def.minimo ? 'Baixo' : 'OK';
                    return (
                      <tr key={def.id} className="border-b hover:bg-muted/50">
                        <td className="py-3 px-4 font-semibold">{def.nome}</td>
                        <td className="py-3 px-4">{def.quantidade} {def.unidade}</td>
                        <td className="py-3 px-4">{def.minimo} {def.unidade}</td>
                        <td className="py-3 px-4">R$ {def.preco.toFixed(2)}</td>
                        <td className="py-3 px-4">R$ {(def.quantidade * def.preco).toFixed(2)}</td>
                        <td className="py-3 px-4">
                          <span className={`text-xs px-2 py-1 rounded-full ${
                            status === 'OK' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                          }`}>
                            {status}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </TabsContent>

          {/* Rações Tab */}
          <TabsContent value="racoes" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {racoes.map((racao) => (
                <Card key={racao.id} className="p-4">
                  <h3 className="font-semibold mb-3">{racao.nome}</h3>
                  <div className="space-y-2 text-sm">
                    <p>Quantidade: <strong>{racao.quantidade} {racao.unidade}</strong></p>
                    <p>Mínimo: <strong>{racao.minimo} {racao.unidade}</strong></p>
                    <p>Preço Unit.: <strong>R$ {racao.preco.toFixed(2)}</strong></p>
                    <p>Valor Total: <strong>R$ {(racao.quantidade * racao.preco).toFixed(2)}</strong></p>
                    <div className="mt-3">
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-green-600 h-2 rounded-full"
                          style={{ width: `${Math.min((racao.quantidade / racao.minimo) * 100, 100)}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Medicamentos Tab */}
          <TabsContent value="medicamentos" className="space-y-4">
            <div className="space-y-3">
              {medicamentos.map((med) => (
                <Card key={med.id} className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold">{med.nome}</p>
                      <p className="text-sm text-muted-foreground">
                        {med.quantidade} {med.unidade} (Mín: {med.minimo})
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">R$ {(med.quantidade * med.preco).toFixed(2)}</p>
                      <p className="text-xs text-muted-foreground">Unit: R$ {med.preco.toFixed(2)}</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Movimentações Tab */}
          <TabsContent value="movimentacoes" className="space-y-4">
            <div className="space-y-3">
              {movimentacoes.map((mov) => (
                <Card key={mov.id} className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      {mov.tipo === 'Entrada' ? (
                        <div className="p-2 rounded-lg bg-green-100">
                          <BarChart3 className="h-5 w-5 text-green-600" />
                        </div>
                      ) : (
                        <div className="p-2 rounded-lg bg-red-100">
                          <TrendingDown className="h-5 w-5 text-red-600" />
                        </div>
                      )}
                      <div>
                        <p className="font-semibold">{mov.item}</p>
                        <p className="text-sm text-muted-foreground">{mov.data} - {mov.usuario}</p>
                      </div>
                    </div>
                    <p className={`font-semibold ${mov.tipo === 'Entrada' ? 'text-green-600' : 'text-red-600'}`}>
                      {mov.tipo === 'Entrada' ? '+' : '-'}{mov.quantidade}
                    </p>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Resumo */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Valor Total Estoque</p>
            <p className="text-2xl font-bold mt-2">R$ 12.450</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Itens em Estoque</p>
            <p className="text-2xl font-bold mt-2">12</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Alertas Críticos</p>
            <p className="text-2xl font-bold mt-2 text-red-600">1</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Itens Baixos</p>
            <p className="text-2xl font-bold mt-2 text-yellow-600">1</p>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
