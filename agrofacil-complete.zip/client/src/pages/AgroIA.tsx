import { useAuth } from '@/_core/hooks/useAuth';
import DashboardLayout from '@/components/DashboardLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Send,
  Leaf,
  AlertCircle,
  Zap,
  Lightbulb,
  Camera,
  MessageCircle,
  Loader2,
} from 'lucide-react';
import { useState, useRef, useEffect } from 'react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

/**
 * AgroIA - Assistente Inteligente com IA
 * Chat conversacional, diagnósticos por foto, recomendações agronômicas
 */
export default function AgroIA() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; content: string }>>([
    {
      role: 'assistant',
      content: 'Olá! Sou a AgroIA, seu assistente inteligente de agricultura. Como posso ajudar você hoje?',
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('chat');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to latest message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Mock conversation handler
  const handleSendMessage = async () => {
    if (!input.trim()) return;

    // Add user message
    const userMessage = input;
    setMessages((prev) => [...prev, { role: 'user', content: userMessage }]);
    setInput('');
    setIsLoading(true);

    // Simulate AI response
    setTimeout(() => {
      const responses = [
        'Entendi sua pergunta sobre agricultura. Com base nos dados da sua fazenda, recomendo...',
        'Analisando as condições climáticas e o histórico de plantios, sugiro...',
        'De acordo com as melhores práticas agrícolas, você deveria considerar...',
        'Baseado no tipo de solo e cultura, a melhor abordagem seria...',
      ];

      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      setMessages((prev) => [...prev, { role: 'assistant', content: randomResponse }]);
      setIsLoading(false);
    }, 1500);
  };

  const diagnosticSuggestions = [
    {
      icon: Leaf,
      title: 'Diagnóstico Vegetal',
      description: 'Tire uma foto da planta para análise de pragas, doenças ou deficiências',
      action: 'Fazer Diagnóstico',
    },
    {
      icon: AlertCircle,
      title: 'Diagnóstico Animal',
      description: 'Analise a saúde e comportamento do seu rebanho',
      action: 'Diagnosticar Animal',
    },
    {
      icon: Zap,
      title: 'Recomendações Agronômicas',
      description: 'Receba recomendações personalizadas para sua fazenda',
      action: 'Gerar Recomendações',
    },
    {
      icon: Lightbulb,
      title: 'Modo Futuro da Fazenda',
      description: 'Simule "e se?" cenários para otimizar sua produção',
      action: 'Iniciar Simulação',
    },
  ];

  const recentConversations = [
    {
      id: 1,
      title: 'Praga de broca do milho',
      date: '2 horas atrás',
      messages: 3,
    },
    {
      id: 2,
      title: 'Análise de solo para soja',
      date: '1 dia atrás',
      messages: 5,
    },
    {
      id: 3,
      title: 'Planejamento de rotação de culturas',
      date: '3 dias atrás',
      messages: 8,
    },
    {
      id: 4,
      title: 'Saúde do rebanho de gado',
      date: '1 semana atrás',
      messages: 12,
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold">AgroIA - Assistente Inteligente</h1>
          <p className="text-muted-foreground mt-2">
            Inteligência artificial para otimizar sua produção agrícola
          </p>
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="chat">Chat</TabsTrigger>
            <TabsTrigger value="diagnostics">Diagnósticos</TabsTrigger>
            <TabsTrigger value="history">Histórico</TabsTrigger>
          </TabsList>

          {/* Chat Tab */}
          <TabsContent value="chat" className="space-y-4">
            <Card className="h-[500px] flex flex-col">
              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {messages.map((msg, idx) => (
                  <div
                    key={idx}
                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                        msg.role === 'user'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted text-muted-foreground'
                      }`}
                    >
                      <p className="text-sm">{msg.content}</p>
                    </div>
                  </div>
                ))}
                {isLoading && (
                  <div className="flex justify-start">
                    <div className="bg-muted text-muted-foreground px-4 py-2 rounded-lg">
                      <Loader2 className="h-4 w-4 animate-spin" />
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Input */}
              <div className="border-t p-4 flex gap-2">
                <Input
                  placeholder="Digite sua pergunta..."
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  disabled={isLoading}
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={isLoading || !input.trim()}
                  size="icon"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </Card>
          </TabsContent>

          {/* Diagnostics Tab */}
          <TabsContent value="diagnostics" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {diagnosticSuggestions.map((suggestion, idx) => {
                const Icon = suggestion.icon;
                return (
                  <Card key={idx} className="p-6 hover:shadow-lg transition-shadow">
                    <div className="flex items-start gap-4">
                      <div className="p-3 rounded-lg bg-primary/10">
                        <Icon className="h-6 w-6 text-primary" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold mb-1">{suggestion.title}</h3>
                        <p className="text-sm text-muted-foreground mb-4">
                          {suggestion.description}
                        </p>
                        <Button size="sm" variant="outline" className="w-full">
                          {suggestion.action}
                        </Button>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>

            {/* Diagnostic Features */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Como Funciona</h3>
              <div className="space-y-3 text-sm text-muted-foreground">
                <p>
                  <strong>Diagnóstico Vegetal:</strong> Tire uma foto clara da planta afetada. Nossa IA analisará a imagem e identificará pragas, doenças ou deficiências nutricionais, fornecendo recomendações de tratamento.
                </p>
                <p>
                  <strong>Diagnóstico Animal:</strong> Descreva os sintomas ou comportamentos anormais do animal. Nossa IA fornecerá análise de saúde e recomendações de ação.
                </p>
                <p>
                  <strong>Recomendações Agronômicas:</strong> Baseado no histórico da sua fazenda, clima e solo, receba recomendações personalizadas para otimizar produção.
                </p>
                <p>
                  <strong>Modo Futuro:</strong> Simule cenários "e se?" para testar diferentes estratégias antes de implementar.
                </p>
              </div>
            </Card>
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history" className="space-y-4">
            <div className="space-y-3">
              {recentConversations.map((conv) => (
                <Card key={conv.id} className="p-4 hover:bg-muted/50 cursor-pointer transition">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <MessageCircle className="h-5 w-5 text-primary" />
                      <div>
                        <p className="font-semibold">{conv.title}</p>
                        <p className="text-xs text-muted-foreground">{conv.date}</p>
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {conv.messages} mensagens
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            {recentConversations.length === 0 && (
              <Card className="p-12 text-center">
                <MessageCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <p className="text-muted-foreground">Nenhuma conversa anterior</p>
              </Card>
            )}
          </TabsContent>
        </Tabs>

        {/* Quick Tips */}
        <Card className="p-6 bg-blue-50 border-blue-200">
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-blue-600" />
            Dicas para Melhores Resultados
          </h3>
          <ul className="text-sm text-muted-foreground space-y-2">
            <li>• Use fotos bem iluminadas para diagnósticos visuais</li>
            <li>• Forneça contexto detalhado (clima, solo, histórico de plantios)</li>
            <li>• Faça perguntas específicas para recomendações mais precisas</li>
            <li>• Valide as recomendações com um agrônomo local quando necessário</li>
          </ul>
        </Card>
      </div>
    </DashboardLayout>
  );
}
