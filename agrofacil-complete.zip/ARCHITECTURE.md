# Arquitetura AgroFácil

## Visão Geral

AgroFácil é uma plataforma SaaS de gestão rural inteligente, desenvolvida com:
- **Frontend**: React 19 + Next.js + TypeScript + Tailwind CSS 4
- **Backend**: Node.js + Express 4 + tRPC 11
- **Banco de Dados**: MySQL/PostgreSQL com Drizzle ORM
- **IA**: OpenAI GPT + Google Gemini (via Manus API)
- **Autenticação**: OAuth Manus + JWT + 2FA
- **Armazenamento**: AWS S3 (via Manus Storage)

## Design Visual

### Paleta de Cores
- **Primária**: #1E7D32 (Verde Agro — confiança e natureza)
- **Secundária**: #FFFFFF (Branco — clareza)
- **Destaque**: #4CAF50 (Verde Claro — ação e crescimento)
- **Apoio**: #F5F5F5 (Cinza Claro — fundo)
- **Sucesso**: #2E7D32 (Verde Escuro)
- **Alerta**: #F57C00 (Laranja)
- **Erro**: #C62828 (Vermelho)
- **Info**: #1976D2 (Azul)

### Tipografia
- **Principal**: Poppins (Google Fonts)
- **Secundária**: Inter (fallback)

### Estilo Visual
- Moderno, minimalista e profissional
- Inspirado em startups de tecnologia (Figma, Notion, Stripe)
- Componentes com sombras suaves e bordas arredondadas
- Animações suaves (200-300ms)
- Responsivo mobile-first
- Modo claro por padrão (tema escuro opcional)

## Estrutura de Banco de Dados

### Tabelas Principais
1. **users** — Usuários com roles (user/admin)
2. **subscriptions** — Planos e assinaturas
3. **farms** — Propriedades rurais
4. **crops** — Culturas e talhões
5. **animals** — Rebanho e histórico
6. **finances** — Receitas, despesas, fluxo de caixa
7. **inventory** — Estoque de insumos
8. **machinery** — Máquinas e horas de uso
9. **employees** — Funcionários e escalas
10. **alerts** — Alertas inteligentes
11. **reports** — Relatórios gerados
12. **market_prices** — Cotações em tempo real
13. **network_alerts** — Rede AgroFácil (alertas colaborativos)

## Rotas Principais

### Públicas
- `/` — Landing Page
- `/login` — Login OAuth
- `/signup` — Criar conta

### Autenticadas (User)
- `/dashboard` — Dashboard principal
- `/agroia` — Assistente inteligente
- `/crops` — Gestão agrícola
- `/animals` — Gestão pecuária
- `/finances` — Controle financeiro
- `/inventory` — Controle de estoque
- `/machinery` — Gestão de máquinas
- `/employees` — Gestão de funcionários
- `/market` — Mercado Agro
- `/network` — Rede AgroFácil
- `/reports` — Relatórios
- `/settings` — Configurações

### Admin
- `/admin` — Painel administrativo
- `/admin/users` — Gerenciar usuários
- `/admin/subscriptions` — Gerenciar assinaturas
- `/admin/payments` — Gerenciar pagamentos
- `/admin/analytics` — Analytics

## Fluxo de Autenticação

1. Usuário clica "Entrar" → Redirecionado para OAuth Manus
2. Após autenticação → Callback em `/api/oauth/callback`
3. JWT gerado e armazenado em cookie seguro
4. Usuário redirecionado para `/dashboard`
5. Cada requisição tRPC valida JWT via `protectedProcedure`

## Fluxo de Assinatura

1. Usuário seleciona plano na Landing Page
2. Redirecionado para checkout (Stripe integrado)
3. Após pagamento → Assinatura criada no banco
4. Acesso a funcionalidades desbloqueadas conforme plano

## Fluxo de AgroIA

1. Usuário envia mensagem ou foto
2. Backend processa com OpenAI/Gemini
3. Resposta formatada com recomendações
4. Histórico salvo no banco de dados

## Segurança

- **Autenticação**: OAuth + JWT
- **Autorização**: Role-based (user/admin)
- **Criptografia**: Senhas com bcrypt
- **2FA**: TOTP (Time-based One-Time Password)
- **HTTPS**: Obrigatório em produção
- **CORS**: Configurado para domínio específico
- **Rate Limiting**: Implementado em endpoints críticos
- **SQL Injection**: Prevenido com Drizzle ORM
- **XSS**: Prevenido com React sanitization
- **LGPD**: Conformidade com lei brasileira

## Performance

- **Frontend**: Vite + lazy loading + code splitting
- **Backend**: tRPC com caching + query optimization
- **Banco**: Índices em colunas frequentes
- **Storage**: S3 com CloudFront (CDN)
- **API**: Rate limiting + pagination

## Escalabilidade

- **Multitenancy**: Cada usuário isolado por `userId`
- **Sharding**: Possível por `farmId` se necessário
- **Cache**: Redis para sessões e dados frequentes
- **Queue**: Bull para jobs assíncronos (relatórios, alertas)
- **Webhooks**: Para integrações externas

## Monitoramento

- **Logs**: Estruturados com Winston
- **Erros**: Sentry para rastreamento
- **Métricas**: Prometheus + Grafana
- **Uptime**: Healthcheck em `/api/health`

## Roadmap

### MVP (Fase 1)
- Landing Page
- Autenticação OAuth
- Dashboard básico
- AgroIA com chat
- Gestão agrícola básica

### Fase 2
- Gestão pecuária completa
- Controle financeiro
- Mercado Agro
- Relatórios

### Fase 3
- Painel administrativo
- 2FA
- Rede AgroFácil
- Integração ERP

### Fase 4
- Mobile app (React Native)
- Offline-first sync
- Visão computacional avançada
- Previsões com ML
