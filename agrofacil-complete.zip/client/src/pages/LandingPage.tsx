import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { getLoginUrl } from '@/const';
import {
  Leaf,
  Zap,
  TrendingUp,
  AlertCircle,
  BarChart3,
  Droplets,
  Wind,
  Smartphone,
  Lock,
  Users,
  Clock,
  CheckCircle,
  ChevronDown,
  Menu,
  X,
} from 'lucide-react';
import { useState } from 'react';
import { Link } from 'wouter';

/**
 * Landing Page for AgroFácil
 * Comprehensive agricultural management platform with AI
 */
export default function LandingPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const benefits = [
    {
      icon: Leaf,
      title: 'Diagnóstico Vegetal',
      description: 'IA detecta pragas, doenças e deficiências nutricionais por foto',
    },
    {
      icon: AlertCircle,
      title: 'Diagnóstico Animal',
      description: 'Análise de saúde e comportamento do rebanho',
    },
    {
      icon: BarChart3,
      title: 'Gestão Agrícola',
      description: 'Controle completo de culturas, talhões e colheitas',
    },
    {
      icon: Zap,
      title: 'Gestão Pecuária',
      description: 'Cadastro de animais, vacinações e reprodução',
    },
    {
      icon: Droplets,
      title: 'Análise de Solo',
      description: 'Recomendações de adubação baseadas em dados',
    },
    {
      icon: Wind,
      title: 'Monitoramento Climático',
      description: 'Previsão de 15 dias e alertas de clima extremo',
    },
    {
      icon: TrendingUp,
      title: 'Relatórios Automáticos',
      description: 'Exportação em PDF e Excel com recomendações',
    },
    {
      icon: AlertCircle,
      title: 'Alertas Inteligentes',
      description: 'Notificações em tempo real de riscos',
    },
    {
      icon: BarChart3,
      title: 'Simulação de Produção',
      description: 'Modo Futuro: "E se eu trocar de cultura?"',
    },
    {
      icon: TrendingUp,
      title: 'Controle Financeiro',
      description: 'Receitas, despesas, fluxo de caixa e lucro',
    },
    {
      icon: Smartphone,
      title: 'Controle de Estoque',
      description: 'Fertilizantes, defensivos, rações e medicamentos',
    },
    {
      icon: Clock,
      title: 'Controle de Máquinas',
      description: 'Horas de uso, combustível e manutenções',
    },
    {
      icon: Users,
      title: 'Gestão de Funcionários',
      description: 'Cadastro, salário e escala de trabalho',
    },
    {
      icon: TrendingUp,
      title: 'Mercado Agro',
      description: 'Cotações em tempo real de commodities',
    },
    {
      icon: Zap,
      title: 'Rede AgroFácil',
      description: 'Alertas colaborativos regionais de pragas',
    },
  ];

  const plans = [
    {
      name: 'Starter',
      price: 'US$ 15',
      period: '/mês',
      description: 'Perfeito para pequenos produtores',
      features: [
        '50 análises mensais',
        'Diagnóstico vegetal',
        'Relatórios básicos',
        'Monitoramento climático',
        'Suporte por email',
      ],
      cta: 'Começar Agora',
      highlighted: false,
    },
    {
      name: 'Producer',
      price: 'US$ 30',
      period: '/mês',
      description: 'Para produtores em crescimento',
      features: [
        '250 análises mensais',
        'Diagnóstico vegetal + animal',
        'Alertas inteligentes',
        'Relatórios avançados',
        'Gestão de estoque',
        'Suporte prioritário',
      ],
      cta: 'Começar Agora',
      highlighted: false,
    },
    {
      name: 'Professional',
      price: 'US$ 60',
      period: '/mês',
      description: 'Para operações médias',
      features: [
        'Análises ilimitadas',
        'AgroIA completa',
        'Gestão financeira',
        'Gestão pecuária',
        'Simulador agrícola',
        'Mercado Agro',
        'Suporte 24/7',
      ],
      cta: 'Começar Agora',
      highlighted: true,
    },
    {
      name: 'Enterprise',
      price: 'US$ 120',
      period: '/mês',
      description: 'Para grandes operações',
      features: [
        'Tudo ilimitado',
        'Multiusuários',
        'API exclusiva',
        'Integração ERP',
        'Dashboard executivo',
        'Rede AgroFácil',
        'Suporte dedicado',
      ],
      cta: 'Falar com Vendas',
      highlighted: false,
    },
  ];

  const faqs = [
    {
      question: 'Como funciona o diagnóstico por IA?',
      answer:
        'Você tira uma foto da planta ou animal afetado. Nossa IA (AgroIA) analisa a imagem e identifica pragas, doenças, deficiências nutricionais ou problemas de saúde, fornecendo recomendações de tratamento com produtos e dosagens.',
    },
    {
      question: 'Qual é o limite de análises por plano?',
      answer:
        'Starter: 50 análises/mês. Producer: 250 análises/mês. Professional e Enterprise: análises ilimitadas. As análises se renovam no início de cada mês.',
    },
    {
      question: 'Posso usar em celular?',
      answer:
        'Sim! AgroFácil é totalmente responsivo e funciona perfeitamente em smartphones, tablets e desktops. Você pode até instalar como app PWA (Progressive Web App) para acesso offline.',
    },
    {
      question: 'Como funciona a Rede AgroFácil?',
      answer:
        'A Rede AgroFácil funciona como um "Waze do Agro". Quando detectamos surtos de pragas ou doenças em sua região, alertamos produtores próximos (com sua permissão). Você também recebe alertas de outros produtores.',
    },
    {
      question: 'Há período de teste gratuito?',
      answer:
        'Sim! Todos os planos começam com 7 dias de teste gratuito. Sem necessidade de cartão de crédito. Você pode cancelar a qualquer momento.',
    },
    {
      question: 'Como exporto relatórios?',
      answer:
        'Todos os relatórios podem ser exportados em PDF (com logo AgroFácil e assinatura digital) ou Excel. Os relatórios incluem recomendações personalizadas baseadas em dados da sua fazenda.',
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <Leaf className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold text-primary">AgroFácil</span>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-8">
            <Link href="#beneficios" className="text-sm hover:text-primary transition">
              Benefícios
            </Link>
            <Link href="#planos" className="text-sm hover:text-primary transition">
              Planos
            </Link>
            <Link href="#faq" className="text-sm hover:text-primary transition">
              FAQ
            </Link>
            <a href="mailto:contato@agrofacil.com" className="text-sm hover:text-primary transition">
              Contato
            </a>
            <Button asChild variant="default" size="sm">
              <a href={getLoginUrl()}>Entrar</a>
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-border bg-card p-4 space-y-4">
            <Link href="#beneficios" className="block text-sm hover:text-primary">
              Benefícios
            </Link>
            <Link href="#planos" className="block text-sm hover:text-primary">
              Planos
            </Link>
            <Link href="#faq" className="block text-sm hover:text-primary">
              FAQ
            </Link>
            <a href="mailto:contato@agrofacil.com" className="block text-sm hover:text-primary">
              Contato
            </a>
            <Button asChild variant="default" className="w-full">
              <a href={getLoginUrl()}>Entrar</a>
            </Button>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="py-20 md:py-32 bg-gradient-to-br from-primary/5 via-background to-accent/5">
        <div className="container max-w-4xl">
          <div className="space-y-6 text-center">
            <h1 className="text-4xl md:text-6xl font-bold leading-tight">
              A inteligência do agro na palma da sua mão
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
              Plataforma inteligente que conecta tecnologia, inteligência artificial e produtividade no campo. Gestão completa de agricultura, pecuária, finanças e muito mais.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Button asChild size="lg" variant="default">
                <a href={getLoginUrl()}>Começar Agora</a>
              </Button>
              <Button asChild size="lg" variant="outline">
                <a href="#beneficios">Conhecer Recursos</a>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section id="beneficios" className="py-20 md:py-32">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Funcionalidades Poderosas</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Tudo que você precisa para gerenciar sua operação agrícola ou pecuária com eficiência
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {benefits.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <Card key={index} className="p-6 hover:shadow-lg transition-shadow duration-200">
                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-lg bg-primary/10">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">{benefit.title}</h3>
                      <p className="text-sm text-muted-foreground">{benefit.description}</p>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Plans Section */}
      <section id="planos" className="py-20 md:py-32 bg-muted/30">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Planos de Assinatura</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Escolha o plano perfeito para sua operação
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {plans.map((plan, index) => (
              <Card
                key={index}
                className={`relative p-8 flex flex-col ${
                  plan.highlighted ? 'ring-2 ring-primary shadow-lg scale-105' : ''
                }`}
              >
                {plan.highlighted && (
                  <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <span className="bg-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-semibold">
                      Mais Popular
                    </span>
                  </div>
                )}

                <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                <p className="text-sm text-muted-foreground mb-4">{plan.description}</p>

                <div className="mb-6">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-muted-foreground">{plan.period}</span>
                </div>

                <Button asChild className="w-full mb-6" variant={plan.highlighted ? 'default' : 'outline'}>
                  <a href={getLoginUrl()}>{plan.cta}</a>
                </Button>

                <ul className="space-y-3 flex-1">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            ))}
          </div>

          <div className="mt-12 p-6 bg-primary/10 rounded-lg border border-primary/20 text-center">
            <p className="text-sm text-muted-foreground mb-2">Todos os planos incluem</p>
            <p className="font-semibold">7 dias de teste gratuito • Sem cartão de crédito • Cancele a qualquer momento</p>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-20 md:py-32">
        <div className="container max-w-3xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Perguntas Frequentes</h2>
            <p className="text-lg text-muted-foreground">
              Respostas para as dúvidas mais comuns
            </p>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <details key={index} className="group border border-border rounded-lg p-6 cursor-pointer hover:bg-muted/50 transition">
                <summary className="flex items-center justify-between font-semibold">
                  {faq.question}
                  <ChevronDown className="h-5 w-5 group-open:rotate-180 transition-transform" />
                </summary>
                <p className="mt-4 text-muted-foreground">{faq.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-32 bg-primary text-primary-foreground">
        <div className="container text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Pronto para transformar sua fazenda?</h2>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            Comece seu teste gratuito de 7 dias. Sem cartão de crédito necessário.
          </p>
          <Button asChild size="lg" variant="secondary">
            <a href={getLoginUrl()}>Começar Agora</a>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-muted/30 py-12">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Leaf className="h-6 w-6 text-primary" />
                <span className="font-bold text-lg">AgroFácil</span>
              </div>
              <p className="text-sm text-muted-foreground">
                A inteligência do agro na palma da sua mão
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Produto</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#beneficios" className="hover:text-primary transition">Recursos</a></li>
                <li><a href="#planos" className="hover:text-primary transition">Planos</a></li>
                <li><a href="#faq" className="hover:text-primary transition">FAQ</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition">Termos de Uso</a></li>
                <li><a href="#" className="hover:text-primary transition">Política de Privacidade</a></li>
                <li><a href="#" className="hover:text-primary transition">LGPD</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Contato</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="mailto:contato@agrofacil.com" className="hover:text-primary transition">contato@agrofacil.com</a></li>
                <li><a href="tel:+5511999999999" className="hover:text-primary transition">+55 (11) 99999-9999</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
              <p>© 2026 AgroFácil. Todos os direitos reservados.</p>
              <p>Desenvolvido por <span className="font-semibold text-foreground">Nathan Moura</span></p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
