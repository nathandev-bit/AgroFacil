import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

/**
 * Upsert user with proper type handling
 * Updates existing user or creates new one based on openId
 */
export async function upsertUser(user: Partial<InsertUser>): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    // Build values object with required fields
    const values: InsertUser = {
      openId: user.openId,
      name: user.name || "User",
      email: user.email || `user-${Date.now()}@agrofacil.local`,
    };

    // Build update set for duplicate key update
    const updateSet: Record<string, unknown> = {};

    // Optional avatar field
    if (user.avatar !== undefined) {
      values.avatar = user.avatar;
      updateSet.avatar = user.avatar;
    }

    // Login method
    if (user.loginMethod !== undefined && (user.loginMethod === "oauth" || user.loginMethod === "email")) {
      values.loginMethod = user.loginMethod;
      updateSet.loginMethod = user.loginMethod;
    } else {
      values.loginMethod = "oauth";
      updateSet.loginMethod = "oauth";
    }

    // Boolean fields
    if (user.emailVerified !== undefined) {
      values.emailVerified = user.emailVerified;
      updateSet.emailVerified = user.emailVerified;
    }

    if (user.twoFactorEnabled !== undefined) {
      values.twoFactorEnabled = user.twoFactorEnabled;
      updateSet.twoFactorEnabled = user.twoFactorEnabled;
    }

    // Login timestamp
    if (user.lastLoginAt !== undefined) {
      values.lastLoginAt = user.lastLoginAt;
      updateSet.lastLoginAt = user.lastLoginAt;
    } else {
      values.lastLoginAt = new Date();
      updateSet.lastLoginAt = new Date();
    }

    // Role assignment
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    } else {
      values.role = "user";
      updateSet.role = "user";
    }

    // Ensure we have something to update
    if (Object.keys(updateSet).length === 0) {
      updateSet.updatedAt = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

/**
 * Get user by OpenId
 */
export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get user by email
 */
export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db
    .select()
    .from(users)
    .where(eq(users.email, email))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get user by ID
 */
export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db
    .select()
    .from(users)
    .where(eq(users.id, id))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// TODO: Add feature queries here as your schema grows
// - Farm queries
// - Crop queries
// - Livestock queries
// - Financial queries
// - Inventory queries
// - Diagnostic queries
// - Alert queries
