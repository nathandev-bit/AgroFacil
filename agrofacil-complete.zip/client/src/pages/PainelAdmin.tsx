import { useAuth } from '@/_core/hooks/useAuth';
import DashboardLayout from '@/components/DashboardLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Users,
  CreditCard,
  BarChart3,
  Settings,
  AlertCircle,
  CheckCircle,
  XCircle,
  Download,
} from 'lucide-react';

/**
 * Painel Administrativo
 * Gerenciamento de usuários, planos, assinaturas, pagamentos e relatórios
 */
export default function PainelAdmin() {
  const { user } = useAuth();

  const usuarios = [
    { id: 1, nome: 'João Silva', email: 'joao@farm.com', plano: 'Professional', status: 'Ativo' },
    { id: 2, nome: 'Maria Santos', email: 'maria@farm.com', plano: 'Producer', status: 'Ativo' },
    { id: 3, nome: 'Pedro Oliveira', email: 'pedro@farm.com', plano: 'Starter', status: 'Inativo' },
  ];

  const assinaturas = [
    { id: 1, usuario: 'João Silva', plano: 'Professional', valor: 60, status: 'Ativa', proxima: '2026-06-15' },
    { id: 2, usuario: 'Maria Santos', plano: 'Producer', valor: 30, status: 'Ativa', proxima: '2026-06-10' },
    { id: 3, usuario: 'Pedro Oliveira', plano: 'Starter', valor: 15, status: 'Cancelada', proxima: '-' },
  ];

  const pagamentos = [
    { id: 1, usuario: 'João Silva', valor: 60, data: '2026-05-15', metodo: 'Cartão', status: 'Confirmado' },
    { id: 2, usuario: 'Maria Santos', valor: 30, data: '2026-05-10', metodo: 'PIX', status: 'Confirmado' },
    { id: 3, usuario: 'Pedro Oliveira', valor: 15, data: '2026-05-05', metodo: 'Boleto', status: 'Pendente' },
  ];

  const planos = [
    { id: 1, nome: 'Starter', preco: 15, usuarios: 45, receita: 675 },
    { id: 2, nome: 'Producer', preco: 30, usuarios: 78, receita: 2340 },
    { id: 3, nome: 'Professional', preco: 60, usuarios: 120, receita: 7200 },
    { id: 4, nome: 'Enterprise', preco: 120, usuarios: 8, receita: 960 },
  ];

  const relatorios = [
    { id: 1, titulo: 'Relatório Financeiro - Maio 2026', data: '2026-05-31', usuarios: 251, receita: 11175 },
    { id: 2, titulo: 'Análise de Uso - Abril 2026', data: '2026-04-30', usuarios: 240, receita: 10800 },
    { id: 3, titulo: 'Churn Report - Trimestral', data: '2026-05-20', usuarios: 15, receita: -450 },
  ];

  const logs = [
    { id: 1, acao: 'Novo usuário registrado', usuario: 'João Silva', data: '2026-05-25 14:30' },
    { id: 2, acao: 'Upgrade de plano', usuario: 'Maria Santos', data: '2026-05-24 10:15' },
    { id: 3, acao: 'Cancelamento de assinatura', usuario: 'Pedro Oliveira', data: '2026-05-23 16:45' },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold">Painel Administrativo</h1>
          <p className="text-muted-foreground mt-2">
            Gerenciamento de usuários, planos, assinaturas e relatórios
          </p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total de Usuários</p>
                <p className="text-3xl font-bold mt-2">251</p>
              </div>
              <Users className="h-12 w-12 text-blue-600 opacity-50" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Receita Mensal</p>
                <p className="text-3xl font-bold mt-2">R$ 11.1k</p>
              </div>
              <CreditCard className="h-12 w-12 text-green-600 opacity-50" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Taxa de Atividade</p>
                <p className="text-3xl font-bold mt-2">94%</p>
              </div>
              <BarChart3 className="h-12 w-12 text-purple-600 opacity-50" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Churn Rate</p>
                <p className="text-3xl font-bold mt-2">2.1%</p>
              </div>
              <AlertCircle className="h-12 w-12 text-red-600 opacity-50" />
            </div>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="usuarios" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="usuarios">Usuários</TabsTrigger>
            <TabsTrigger value="assinaturas">Assinaturas</TabsTrigger>
            <TabsTrigger value="pagamentos">Pagamentos</TabsTrigger>
            <TabsTrigger value="relatorios">Relatórios</TabsTrigger>
            <TabsTrigger value="logs">Logs</TabsTrigger>
          </TabsList>

          {/* Usuários Tab */}
          <TabsContent value="usuarios" className="space-y-4">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b">
                  <tr>
                    <th className="text-left py-3 px-4">Nome</th>
                    <th className="text-left py-3 px-4">Email</th>
                    <th className="text-left py-3 px-4">Plano</th>
                    <th className="text-left py-3 px-4">Status</th>
                    <th className="text-left py-3 px-4">Ação</th>
                  </tr>
                </thead>
                <tbody>
                  {usuarios.map((user) => (
                    <tr key={user.id} className="border-b hover:bg-muted/50">
                      <td className="py-3 px-4 font-semibold">{user.nome}</td>
                      <td className="py-3 px-4">{user.email}</td>
                      <td className="py-3 px-4">{user.plano}</td>
                      <td className="py-3 px-4">
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          user.status === 'Ativo' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                        }`}>
                          {user.status}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <Button variant="ghost" size="sm">Editar</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </TabsContent>

          {/* Assinaturas Tab */}
          <TabsContent value="assinaturas" className="space-y-4">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b">
                  <tr>
                    <th className="text-left py-3 px-4">Usuário</th>
                    <th className="text-left py-3 px-4">Plano</th>
                    <th className="text-left py-3 px-4">Valor</th>
                    <th className="text-left py-3 px-4">Status</th>
                    <th className="text-left py-3 px-4">Próxima Renovação</th>
                  </tr>
                </thead>
                <tbody>
                  {assinaturas.map((sub) => (
                    <tr key={sub.id} className="border-b hover:bg-muted/50">
                      <td className="py-3 px-4 font-semibold">{sub.usuario}</td>
                      <td className="py-3 px-4">{sub.plano}</td>
                      <td className="py-3 px-4">R$ {sub.valor}</td>
                      <td className="py-3 px-4">
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          sub.status === 'Ativa' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                        }`}>
                          {sub.status}
                        </span>
                      </td>
                      <td className="py-3 px-4">{sub.proxima}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </TabsContent>

          {/* Pagamentos Tab */}
          <TabsContent value="pagamentos" className="space-y-4">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b">
                  <tr>
                    <th className="text-left py-3 px-4">Usuário</th>
                    <th className="text-left py-3 px-4">Valor</th>
                    <th className="text-left py-3 px-4">Data</th>
                    <th className="text-left py-3 px-4">Método</th>
                    <th className="text-left py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {pagamentos.map((pag) => (
                    <tr key={pag.id} className="border-b hover:bg-muted/50">
                      <td className="py-3 px-4 font-semibold">{pag.usuario}</td>
                      <td className="py-3 px-4">R$ {pag.valor}</td>
                      <td className="py-3 px-4">{pag.data}</td>
                      <td className="py-3 px-4">{pag.metodo}</td>
                      <td className="py-3 px-4">
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          pag.status === 'Confirmado' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                        }`}>
                          {pag.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </TabsContent>

          {/* Relatórios Tab */}
          <TabsContent value="relatorios" className="space-y-4">
            <Button className="gap-2">
              <Download className="h-4 w-4" />
              Gerar Novo Relatório
            </Button>
            <div className="space-y-3">
              {relatorios.map((rel) => (
                <Card key={rel.id} className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold">{rel.titulo}</p>
                      <p className="text-sm text-muted-foreground">{rel.data}</p>
                      <p className="text-xs text-muted-foreground mt-2">
                        Usuários: {rel.usuarios} | Receita: R$ {rel.receita.toLocaleString()}
                      </p>
                    </div>
                    <Button variant="outline" size="sm" className="gap-1">
                      <Download className="h-4 w-4" />
                      Download
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Logs Tab */}
          <TabsContent value="logs" className="space-y-4">
            <div className="space-y-3">
              {logs.map((log) => (
                <Card key={log.id} className="p-4">
                  <div className="flex items-start gap-4">
                    <div className="p-2 rounded-lg bg-primary/10">
                      <CheckCircle className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold">{log.acao}</p>
                      <p className="text-sm text-muted-foreground">{log.usuario}</p>
                      <p className="text-xs text-muted-foreground mt-1">{log.data}</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Distribuição de Planos */}
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4">Distribuição de Planos</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {planos.map((plano) => (
              <div key={plano.id} className="p-4 border rounded-lg">
                <p className="font-semibold mb-3">{plano.nome}</p>
                <div className="space-y-2 text-sm">
                  <p>Preço: <strong>R$ {plano.preco}</strong></p>
                  <p>Usuários: <strong>{plano.usuarios}</strong></p>
                  <p>Receita: <strong>R$ {plano.receita.toLocaleString()}</strong></p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </DashboardLayout>
  );
}
