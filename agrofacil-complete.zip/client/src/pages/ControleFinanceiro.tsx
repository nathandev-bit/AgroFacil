import { useAuth } from '@/_core/hooks/useAuth';
import DashboardLayout from '@/components/DashboardLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Plus,
  TrendingUp,
  TrendingDown,
  DollarSign,
  PieChart,
  Calendar,
  Download,
} from 'lucide-react';
import { LineChart, Line, PieChart as PieChartComponent, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

/**
 * Controle Financeiro
 * Receitas, despesas, fluxo de caixa, lucro e gráficos
 */
export default function ControleFinanceiro() {
  const { user } = useAuth();

  const receitas = [
    { id: 1, descricao: 'Venda de Soja', valor: 45000, data: '2026-05-20', categoria: 'Venda' },
    { id: 2, descricao: 'Venda de Milho', valor: 32000, data: '2026-05-18', categoria: 'Venda' },
    { id: 3, descricao: 'Venda de Gado', valor: 28000, data: '2026-05-15', categoria: 'Pecuária' },
  ];

  const despesas = [
    { id: 1, descricao: 'Fertilizante', valor: 8000, data: '2026-05-20', categoria: 'Insumos' },
    { id: 2, descricao: 'Combustível', valor: 5000, data: '2026-05-19', categoria: 'Operacional' },
    { id: 3, descricao: 'Manutenção Trator', valor: 3500, data: '2026-05-17', categoria: 'Manutenção' },
  ];

  const fluxoCaixa = [
    { mes: 'Jan', receita: 45000, despesa: 18000 },
    { mes: 'Fev', receita: 52000, despesa: 22000 },
    { mes: 'Mar', receita: 48000, despesa: 20000 },
    { mes: 'Abr', receita: 55000, despesa: 23000 },
    { mes: 'Mai', receita: 50000, despesa: 21000 },
  ];

  const categoriasDespesas = [
    { name: 'Insumos', value: 35, color: '#10b981' },
    { name: 'Operacional', value: 25, color: '#f59e0b' },
    { name: 'Manutenção', value: 20, color: '#ef4444' },
    { name: 'Pessoal', value: 20, color: '#3b82f6' },
  ];

  const resumoFinanceiro = {
    totalReceita: 250000,
    totalDespesa: 95000,
    lucroLiquido: 155000,
    margem: 62,
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Controle Financeiro</h1>
            <p className="text-muted-foreground mt-2">
              Receitas, despesas, fluxo de caixa e análise de lucro
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="gap-2">
              <Download className="h-4 w-4" />
              Exportar PDF
            </Button>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Nova Transação
            </Button>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-6 bg-gradient-to-br from-green-50 to-emerald-50">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Receita Total</p>
                <p className="text-3xl font-bold text-green-700 mt-2">
                  R$ {(resumoFinanceiro.totalReceita / 1000).toFixed(0)}k
                </p>
              </div>
              <TrendingUp className="h-12 w-12 text-green-600 opacity-50" />
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-red-50 to-pink-50">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Despesa Total</p>
                <p className="text-3xl font-bold text-red-700 mt-2">
                  R$ {(resumoFinanceiro.totalDespesa / 1000).toFixed(0)}k
                </p>
              </div>
              <TrendingDown className="h-12 w-12 text-red-600 opacity-50" />
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-blue-50 to-cyan-50">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Lucro Líquido</p>
                <p className="text-3xl font-bold text-blue-700 mt-2">
                  R$ {(resumoFinanceiro.lucroLiquido / 1000).toFixed(0)}k
                </p>
              </div>
              <DollarSign className="h-12 w-12 text-blue-600 opacity-50" />
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-purple-50 to-pink-50">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Margem de Lucro</p>
                <p className="text-3xl font-bold text-purple-700 mt-2">
                  {resumoFinanceiro.margem}%
                </p>
              </div>
              <PieChart className="h-12 w-12 text-purple-600 opacity-50" />
            </div>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="fluxo" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="fluxo">Fluxo de Caixa</TabsTrigger>
            <TabsTrigger value="receitas">Receitas</TabsTrigger>
            <TabsTrigger value="despesas">Despesas</TabsTrigger>
            <TabsTrigger value="analise">Análise</TabsTrigger>
          </TabsList>

          {/* Fluxo de Caixa Tab */}
          <TabsContent value="fluxo" className="space-y-4">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Últimos 5 Meses</h3>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={fluxoCaixa}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="mes" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="receita" stroke="#10b981" name="Receita" />
                  <Line type="monotone" dataKey="despesa" stroke="#ef4444" name="Despesa" />
                </LineChart>
              </ResponsiveContainer>
            </Card>
          </TabsContent>

          {/* Receitas Tab */}
          <TabsContent value="receitas" className="space-y-4">
            <div className="space-y-3">
              {receitas.map((receita) => (
                <Card key={receita.id} className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <TrendingUp className="h-6 w-6 text-green-600" />
                      <div>
                        <p className="font-semibold">{receita.descricao}</p>
                        <p className="text-sm text-muted-foreground">{receita.data}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-green-600">
                        +R$ {receita.valor.toLocaleString()}
                      </p>
                      <p className="text-xs text-muted-foreground">{receita.categoria}</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Nova Receita
            </Button>
          </TabsContent>

          {/* Despesas Tab */}
          <TabsContent value="despesas" className="space-y-4">
            <div className="space-y-3">
              {despesas.map((despesa) => (
                <Card key={despesa.id} className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <TrendingDown className="h-6 w-6 text-red-600" />
                      <div>
                        <p className="font-semibold">{despesa.descricao}</p>
                        <p className="text-sm text-muted-foreground">{despesa.data}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-red-600">
                        -R$ {despesa.valor.toLocaleString()}
                      </p>
                      <p className="text-xs text-muted-foreground">{despesa.categoria}</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Nova Despesa
            </Button>
          </TabsContent>

          {/* Análise Tab */}
          <TabsContent value="analise" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4">Distribuição de Despesas</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChartComponent>
                    <Pie
                      data={categoriasDespesas}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {categoriasDespesas.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChartComponent>
                </ResponsiveContainer>
              </Card>

              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4">Indicadores Financeiros</h3>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">ROI (Retorno sobre Investimento)</p>
                    <p className="text-2xl font-bold text-green-600 mt-1">163%</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Índice de Lucratividade</p>
                    <p className="text-2xl font-bold text-blue-600 mt-1">62%</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Ticket Médio</p>
                    <p className="text-2xl font-bold text-purple-600 mt-1">R$ 35.000</p>
                  </div>
                </div>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
