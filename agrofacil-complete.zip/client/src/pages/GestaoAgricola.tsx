import { useAuth } from '@/_core/hooks/useAuth';
import DashboardLayout from '@/components/DashboardLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Plus,
  Leaf,
  Bug,
  Droplets,
  BarChart3,
  Calendar,
  MapPin,
  TrendingUp,
} from 'lucide-react';

/**
 * Gestão Agrícola
 * Cadastro de culturas, talhões, plantios, colheitas e monitoramento
 */
export default function GestaoAgricola() {
  const { user } = useAuth();

  const culturas = [
    { id: 1, nome: 'Soja', area: 150, estacao: 'Verão', status: 'Plantada' },
    { id: 2, nome: 'Milho', area: 100, estacao: 'Verão', status: 'Plantada' },
    { id: 3, nome: 'Trigo', area: 80, estacao: 'Inverno', status: 'Colhida' },
  ];

  const talhoes = [
    { id: 1, nome: 'Talhão A1', area: 50, cultura: 'Soja', solo: 'Bom', umidade: 65 },
    { id: 2, nome: 'Talhão A2', area: 45, cultura: 'Soja', solo: 'Excelente', umidade: 72 },
    { id: 3, nome: 'Talhão B1', area: 55, cultura: 'Milho', solo: 'Bom', umidade: 68 },
  ];

  const pragas = [
    { id: 1, talhao: 'A1', praga: 'Broca do Milho', severidade: 'Alta', acao: 'Aplicar inseticida' },
    { id: 2, talhao: 'A2', praga: 'Ferrugem Asiática', severidade: 'Média', acao: 'Monitorar' },
  ];

  const analisesSolo = [
    { id: 1, talhao: 'A1', data: '2026-05-15', pH: 6.2, N: 45, P: 28, K: 180 },
    { id: 2, talhao: 'A2', data: '2026-05-10', pH: 6.5, N: 52, P: 32, K: 195 },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Gestão Agrícola</h1>
            <p className="text-muted-foreground mt-2">
              Culturas, talhões, plantios e monitoramento de pragas e doenças
            </p>
          </div>
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Novo Plantio
          </Button>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="culturas" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="culturas">Culturas</TabsTrigger>
            <TabsTrigger value="talhoes">Talhões</TabsTrigger>
            <TabsTrigger value="pragas">Pragas</TabsTrigger>
            <TabsTrigger value="solo">Solo</TabsTrigger>
            <TabsTrigger value="historico">Histórico</TabsTrigger>
          </TabsList>

          {/* Culturas Tab */}
          <TabsContent value="culturas" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {culturas.map((cultura) => (
                <Card key={cultura.id} className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <Leaf className="h-8 w-8 text-green-600" />
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      cultura.status === 'Plantada' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {cultura.status}
                    </span>
                  </div>
                  <h3 className="font-semibold text-lg mb-2">{cultura.nome}</h3>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p>Área: <strong>{cultura.area} ha</strong></p>
                    <p>Estação: <strong>{cultura.estacao}</strong></p>
                  </div>
                  <Button variant="outline" className="w-full mt-4">
                    Detalhes
                  </Button>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Talhões Tab */}
          <TabsContent value="talhoes" className="space-y-4">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b">
                  <tr>
                    <th className="text-left py-3 px-4">Talhão</th>
                    <th className="text-left py-3 px-4">Cultura</th>
                    <th className="text-left py-3 px-4">Área (ha)</th>
                    <th className="text-left py-3 px-4">Solo</th>
                    <th className="text-left py-3 px-4">Umidade</th>
                    <th className="text-left py-3 px-4">Ação</th>
                  </tr>
                </thead>
                <tbody>
                  {talhoes.map((talhao) => (
                    <tr key={talhao.id} className="border-b hover:bg-muted/50">
                      <td className="py-3 px-4 font-semibold">{talhao.nome}</td>
                      <td className="py-3 px-4">{talhao.cultura}</td>
                      <td className="py-3 px-4">{talhao.area}</td>
                      <td className="py-3 px-4">
                        <span className={`text-xs px-2 py-1 rounded ${
                          talhao.solo === 'Excelente' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                        }`}>
                          {talhao.solo}
                        </span>
                      </td>
                      <td className="py-3 px-4">{talhao.umidade}%</td>
                      <td className="py-3 px-4">
                        <Button variant="ghost" size="sm">Editar</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </TabsContent>

          {/* Pragas Tab */}
          <TabsContent value="pragas" className="space-y-4">
            {pragas.length > 0 ? (
              <div className="space-y-3">
                {pragas.map((praga) => (
                  <Card key={praga.id} className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4">
                        <Bug className="h-6 w-6 text-red-600 mt-1" />
                        <div>
                          <p className="font-semibold">{praga.praga}</p>
                          <p className="text-sm text-muted-foreground">Talhão: {praga.talhao}</p>
                          <p className="text-sm mt-2">Ação recomendada: <strong>{praga.acao}</strong></p>
                        </div>
                      </div>
                      <span className={`text-xs px-2 py-1 rounded-full whitespace-nowrap ${
                        praga.severidade === 'Alta' ? 'bg-red-100 text-red-700' :
                        praga.severidade === 'Média' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-green-100 text-green-700'
                      }`}>
                        {praga.severidade}
                      </span>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="p-12 text-center">
                <Bug className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <p className="text-muted-foreground">Nenhuma praga detectada</p>
              </Card>
            )}
          </TabsContent>

          {/* Solo Tab */}
          <TabsContent value="solo" className="space-y-4">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b">
                  <tr>
                    <th className="text-left py-3 px-4">Talhão</th>
                    <th className="text-left py-3 px-4">Data</th>
                    <th className="text-left py-3 px-4">pH</th>
                    <th className="text-left py-3 px-4">N (ppm)</th>
                    <th className="text-left py-3 px-4">P (ppm)</th>
                    <th className="text-left py-3 px-4">K (ppm)</th>
                  </tr>
                </thead>
                <tbody>
                  {analisesSolo.map((analise) => (
                    <tr key={analise.id} className="border-b hover:bg-muted/50">
                      <td className="py-3 px-4 font-semibold">{analise.talhao}</td>
                      <td className="py-3 px-4">{analise.data}</td>
                      <td className="py-3 px-4">{analise.pH}</td>
                      <td className="py-3 px-4">{analise.N}</td>
                      <td className="py-3 px-4">{analise.P}</td>
                      <td className="py-3 px-4">{analise.K}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Nova Análise de Solo
            </Button>
          </TabsContent>

          {/* Histórico Tab */}
          <TabsContent value="historico" className="space-y-4">
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Histórico de Atividades</h3>
              <div className="space-y-3">
                <div className="flex items-start gap-4 pb-3 border-b">
                  <Calendar className="h-5 w-5 text-primary mt-1" />
                  <div>
                    <p className="font-semibold">Plantio de Soja - Talhão A1</p>
                    <p className="text-sm text-muted-foreground">15 de maio de 2026</p>
                  </div>
                </div>
                <div className="flex items-start gap-4 pb-3 border-b">
                  <Droplets className="h-5 w-5 text-blue-600 mt-1" />
                  <div>
                    <p className="font-semibold">Irrigação - Talhão A2</p>
                    <p className="text-sm text-muted-foreground">10 de maio de 2026</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <BarChart3 className="h-5 w-5 text-green-600 mt-1" />
                  <div>
                    <p className="font-semibold">Análise de Solo - Talhão B1</p>
                    <p className="text-sm text-muted-foreground">5 de maio de 2026</p>
                  </div>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Área Total Plantada</p>
            <p className="text-2xl font-bold mt-2">330 ha</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Culturas Ativas</p>
            <p className="text-2xl font-bold mt-2">3</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Alertas de Praga</p>
            <p className="text-2xl font-bold mt-2 text-red-600">2</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Análises de Solo</p>
            <p className="text-2xl font-bold mt-2">2</p>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
