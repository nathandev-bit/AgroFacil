import { describe, it, expect } from 'vitest';

describe('Gestão Agrícola - Content Validation', () => {
  it('should have 3 culturas', () => {
    const culturas = [
      { nome: 'Soja', area: 150, status: 'Plantada' },
      { nome: 'Milho', area: 100, status: 'Plantada' },
      { nome: 'Trigo', area: 80, status: 'Colhida' },
    ];
    expect(culturas).toHaveLength(3);
  });

  it('should have 3 talhoes', () => {
    const talhoes = [
      { nome: 'Talhão A1', cultura: 'Soja' },
      { nome: 'Talhão A2', cultura: 'Soja' },
      { nome: 'Talhão B1', cultura: 'Milho' },
    ];
    expect(talhoes).toHaveLength(3);
  });

  it('should have pragas com severidade', () => {
    const pragas = [
      { praga: 'Broca do Milho', severidade: 'Alta' },
      { praga: 'Ferrugem Asiática', severidade: 'Média' },
    ];
    expect(pragas).toHaveLength(2);
    pragas.forEach((p) => {
      expect(['Alta', 'Média', 'Baixa']).toContain(p.severidade);
    });
  });

  it('should have analises de solo', () => {
    const analises = [
      { talhao: 'A1', pH: 6.2, N: 45 },
      { talhao: 'A2', pH: 6.5, N: 52 },
    ];
    expect(analises).toHaveLength(2);
  });

  it('should calculate total area', () => {
    const culturas = [
      { area: 150 },
      { area: 100 },
      { area: 80 },
    ];
    const totalArea = culturas.reduce((sum, c) => sum + c.area, 0);
    expect(totalArea).toBe(330);
  });
});
