import { useAuth } from '@/_core/hooks/useAuth';
import DashboardLayout from '@/components/DashboardLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Plus,
  MessageCircle,
  HelpCircle,
  Phone,
  Mail,
  Clock,
  CheckCircle,
} from 'lucide-react';

/**
 * Suporte
 * Central de suporte com tickets, FAQ e contato
 */
export default function Suporte() {
  const { user } = useAuth();

  const tickets = [
    { id: 1, titulo: 'Dúvida sobre cadastro de culturas', status: 'Aberto', prioridade: 'Média', data: '2026-05-25' },
    { id: 2, titulo: 'Erro ao exportar relatório', status: 'Em Análise', prioridade: 'Alta', data: '2026-05-24' },
    { id: 3, titulo: 'Como usar AgroIA?', status: 'Resolvido', prioridade: 'Baixa', data: '2026-05-23' },
  ];

  const faq = [
    { id: 1, pergunta: 'Como cadastrar uma nova cultura?', resposta: 'Acesse Gestão Agrícola > Culturas > Novo Plantio e preencha os dados.' },
    { id: 2, pergunta: 'Qual é a melhor forma de usar AgroIA?', resposta: 'Use o chat para fazer perguntas sobre sua fazenda, diagnósticos e recomendações.' },
    { id: 3, pergunta: 'Como exportar relatórios em PDF?', resposta: 'Vá para Relatórios > Novo Relatório e escolha o formato PDF.' },
    { id: 4, pergunta: 'Como integrar com APIs externas?', resposta: 'Acesse Configurações > Integrações e siga as instruções.' },
    { id: 5, pergunta: 'Qual é o suporte para 2FA?', resposta: 'Ative 2FA em Configurações > Segurança para proteger sua conta.' },
  ];

  const contatos = [
    { id: 1, tipo: 'Email', valor: 'suporte@agrofacil.com.br', disponivel: true },
    { id: 2, tipo: 'WhatsApp', valor: '(11) 98765-4321', disponivel: true },
    { id: 3, tipo: 'Telefone', valor: '(11) 3000-0000', disponivel: true },
    { id: 4, tipo: 'Chat', valor: 'Chat ao vivo', disponivel: true },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Suporte</h1>
            <p className="text-muted-foreground mt-2">
              Central de suporte com tickets, FAQ e contato
            </p>
          </div>
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Novo Ticket
          </Button>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="tickets" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="tickets">Meus Tickets</TabsTrigger>
            <TabsTrigger value="faq">FAQ</TabsTrigger>
            <TabsTrigger value="contato">Contato</TabsTrigger>
          </TabsList>

          {/* Tickets Tab */}
          <TabsContent value="tickets" className="space-y-4">
            <div className="space-y-3">
              {tickets.map((ticket) => (
                <Card key={ticket.id} className={`p-4 border-l-4 ${
                  ticket.status === 'Aberto' ? 'border-blue-500' :
                  ticket.status === 'Em Análise' ? 'border-yellow-500' :
                  'border-green-500'
                }`}>
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="font-semibold">{ticket.titulo}</p>
                      <p className="text-sm text-muted-foreground">{ticket.data}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        ticket.prioridade === 'Alta' ? 'bg-red-100 text-red-700' :
                        ticket.prioridade === 'Média' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-green-100 text-green-700'
                      }`}>
                        {ticket.prioridade}
                      </span>
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        ticket.status === 'Aberto' ? 'bg-blue-100 text-blue-700' :
                        ticket.status === 'Em Análise' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-green-100 text-green-700'
                      }`}>
                        {ticket.status}
                      </span>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="mt-3">Ver Detalhes</Button>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* FAQ Tab */}
          <TabsContent value="faq" className="space-y-4">
            <div className="space-y-3">
              {faq.map((item) => (
                <Card key={item.id} className="p-4">
                  <div className="flex items-start gap-3">
                    <HelpCircle className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="font-semibold mb-2">{item.pergunta}</p>
                      <p className="text-sm text-muted-foreground">{item.resposta}</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Contato Tab */}
          <TabsContent value="contato" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {contatos.map((contato) => (
                <Card key={contato.id} className="p-6">
                  <div className="flex items-start gap-4 mb-4">
                    {contato.tipo === 'Email' && <Mail className="h-6 w-6 text-blue-600" />}
                    {contato.tipo === 'WhatsApp' && <MessageCircle className="h-6 w-6 text-green-600" />}
                    {contato.tipo === 'Telefone' && <Phone className="h-6 w-6 text-purple-600" />}
                    {contato.tipo === 'Chat' && <MessageCircle className="h-6 w-6 text-orange-600" />}
                    <div>
                      <p className="font-semibold">{contato.tipo}</p>
                      <p className="text-sm text-muted-foreground">{contato.valor}</p>
                    </div>
                  </div>
                  <Button className="w-full">Contatar</Button>
                </Card>
              ))}
            </div>

            {/* Horário de Atendimento */}
            <Card className="p-6 bg-gradient-to-br from-blue-50 to-cyan-50">
              <div className="flex items-start gap-3">
                <Clock className="h-6 w-6 text-blue-600 mt-1" />
                <div>
                  <p className="font-semibold mb-2">Horário de Atendimento</p>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>Segunda a Sexta: 08:00 - 18:00</p>
                    <p>Sábado: 08:00 - 12:00</p>
                    <p>Domingo e Feriados: Fechado</p>
                  </div>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Tickets Abertos</p>
            <p className="text-2xl font-bold mt-2">1</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Em Análise</p>
            <p className="text-2xl font-bold mt-2">1</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Resolvidos</p>
            <p className="text-2xl font-bold mt-2 text-green-600">1</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-muted-foreground">Tempo Médio</p>
            <p className="text-2xl font-bold mt-2">2h 30m</p>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
