import { useAuth } from '@/_core/hooks/useAuth';
import DashboardLayout from '@/components/DashboardLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Plus,
  Users,
  DollarSign,
  Calendar,
  AlertCircle,
  CheckCircle,
} from 'lucide-react';

/**
 * Gestão de Funcionários
 * Cadastro, salário, escala de trabalho e atividades
 */
export default function GestaFuncionarios() {
  const { user } = useAuth();

  const funcionarios = [
    { id: 1, nome: 'João da Silva', cargo: 'Operador de Máquinas', salario: 3500, status: 'Ativo' },
    { id: 2, nome: 'Maria Santos', cargo: 'Técnica Agrícola', salario: 4000, status: 'Ativo' },
    { id: 3, nome: 'Pedro Oliveira', cargo: 'Peão de Fazenda', salario: 2800, status: 'Ativo' },
    { id: 4, nome: 'Ana Costa', cargo: 'Veterinária', salario: 5000, status: 'Ativo' },
  ];

  const folhaPagamento = [
    { id: 1, funcionario: 'João da Silva', salario: 3500, bonus: 200, desconto: 350, liquido: 3350 },
    { id: 2, funcionario: 'Maria Santos', salario: 4000, bonus: 300, desconto: 400, liquido: 3900 },
    { id: 3, funcionario: 'Pedro Oliveira', salario: 2800, bonus: 100, desconto: 280, liquido: 2620 },
    { id: 4, funcionario: 'Ana Costa', salario: 5000, bonus: 500, desconto: 500, liquido: 5000 },
  ];

  const escala = [
    { id: 1, funcionario: 'João da Silva', data: '2026-05-26', turno: 'Manhã', atividade: 'Plantio' },
    { id: 2, funcionario: 'Maria Santos', data: '2026-05-26', turno: 'Tarde', atividade: 'Monitoramento' },
    { id: 3, funcionario: 'Pedro Oliveira', data: '2026-05-26', turno: 'Manhã', atividade: 'Irrigação' },
    { id: 4, funcionario: 'Ana Costa', data: '2026-05-26', turno: 'Tarde', atividade: 'Vacinação' },
  ];

  const atividades = [
    { id: 1, funcionario: 'João da Silva', data: '2026-05-25', atividade: 'Plantio de Soja', horas: 8 },
    { id: 2, funcionario: 'Maria Santos', data: '2026-05-25', atividade: 'Análise de Solo', horas: 6 },
    { id: 3, funcionario: 'Pedro Oliveira', data: '2026-05-25', atividade: 'Manutenção de Cerca', horas: 8 },
    { id: 4, funcionario: 'Ana Costa', data: '2026-05-25', atividade: 'Vacinação de Gado', horas: 7 },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Gestão de Funcionários</h1>
            <p className="text-muted-foreground mt-2">
              Cadastro, salário, escala de trabalho e atividades
            </p>
          </div>
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Novo Funcionário
          </Button>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total de Funcionários</p>
                <p className="text-3xl font-bold mt-2">4</p>
              </div>
              <Users className="h-12 w-12 text-blue-600 opacity-50" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Folha de Pagamento</p>
                <p className="text-3xl font-bold mt-2">R$ 14.8k</p>
              </div>
              <DollarSign className="h-12 w-12 text-green-600 opacity-50" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Ativos</p>
                <p className="text-3xl font-bold mt-2 text-green-600">4</p>
              </div>
              <CheckCircle className="h-12 w-12 text-green-600 opacity-50" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Horas Trabalhadas</p>
                <p className="text-3xl font-bold mt-2">29h</p>
              </div>
              <Calendar className="h-12 w-12 text-purple-600 opacity-50" />
            </div>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="funcionarios" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="funcionarios">Funcionários</TabsTrigger>
            <TabsTrigger value="folha">Folha de Pagamento</TabsTrigger>
            <TabsTrigger value="escala">Escala de Trabalho</TabsTrigger>
            <TabsTrigger value="atividades">Atividades</TabsTrigger>
          </TabsList>

          {/* Funcionários Tab */}
          <TabsContent value="funcionarios" className="space-y-4">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b">
                  <tr>
                    <th className="text-left py-3 px-4">Nome</th>
                    <th className="text-left py-3 px-4">Cargo</th>
                    <th className="text-left py-3 px-4">Salário</th>
                    <th className="text-left py-3 px-4">Status</th>
                    <th className="text-left py-3 px-4">Ação</th>
                  </tr>
                </thead>
                <tbody>
                  {funcionarios.map((func) => (
                    <tr key={func.id} className="border-b hover:bg-muted/50">
                      <td className="py-3 px-4 font-semibold">{func.nome}</td>
                      <td className="py-3 px-4">{func.cargo}</td>
                      <td className="py-3 px-4">R$ {func.salario.toLocaleString()}</td>
                      <td className="py-3 px-4">
                        <span className="text-xs px-2 py-1 rounded-full bg-green-100 text-green-700">
                          {func.status}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <Button variant="ghost" size="sm">Editar</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </TabsContent>

          {/* Folha de Pagamento Tab */}
          <TabsContent value="folha" className="space-y-4">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b">
                  <tr>
                    <th className="text-left py-3 px-4">Funcionário</th>
                    <th className="text-left py-3 px-4">Salário</th>
                    <th className="text-left py-3 px-4">Bônus</th>
                    <th className="text-left py-3 px-4">Desconto</th>
                    <th className="text-left py-3 px-4">Líquido</th>
                  </tr>
                </thead>
                <tbody>
                  {folhaPagamento.map((folha) => (
                    <tr key={folha.id} className="border-b hover:bg-muted/50">
                      <td className="py-3 px-4 font-semibold">{folha.funcionario}</td>
                      <td className="py-3 px-4">R$ {folha.salario.toLocaleString()}</td>
                      <td className="py-3 px-4 text-green-600">+R$ {folha.bonus.toLocaleString()}</td>
                      <td className="py-3 px-4 text-red-600">-R$ {folha.desconto.toLocaleString()}</td>
                      <td className="py-3 px-4 font-semibold">R$ {folha.liquido.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Gerar Folha
            </Button>
          </TabsContent>

          {/* Escala de Trabalho Tab */}
          <TabsContent value="escala" className="space-y-4">
            <div className="space-y-3">
              {escala.map((esc) => (
                <Card key={esc.id} className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold">{esc.funcionario}</p>
                      <p className="text-sm text-muted-foreground">{esc.data} - Turno: {esc.turno}</p>
                      <p className="text-sm mt-2">Atividade: <strong>{esc.atividade}</strong></p>
                    </div>
                    <Button variant="outline" size="sm">Editar</Button>
                  </div>
                </Card>
              ))}
            </div>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Nova Escala
            </Button>
          </TabsContent>

          {/* Atividades Tab */}
          <TabsContent value="atividades" className="space-y-4">
            <div className="space-y-3">
              {atividades.map((ativ) => (
                <Card key={ativ.id} className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold">{ativ.funcionario}</p>
                      <p className="text-sm text-muted-foreground">{ativ.data}</p>
                      <p className="text-sm mt-2">{ativ.atividade}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold">{ativ.horas}h</p>
                      <p className="text-xs text-muted-foreground">trabalhadas</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Registrar Atividade
            </Button>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
