import { describe, it, expect } from 'vitest';

describe('Gestão Pecuária - Content Validation', () => {
  it('should have 3 animais', () => {
    const animais = [
      { numero: '001', raca: 'Nelore', peso: 450 },
      { numero: '002', raca: 'Nelore', peso: 480 },
      { numero: '003', raca: 'Angus', peso: 520 },
    ];
    expect(animais).toHaveLength(3);
  });

  it('should have vacinacoes com proxima dose', () => {
    const vacinacoes = [
      { vacina: 'Aftosa', proxima: '2026-11-15' },
      { vacina: 'Brucelose', proxima: '2027-04-20' },
      { vacina: 'Raiva', proxima: '2027-05-10' },
    ];
    expect(vacinacoes).toHaveLength(3);
    vacinacoes.forEach((v) => {
      expect(v.proxima).toBeTruthy();
    });
  });

  it('should have medicamentos com motivo', () => {
    const medicamentos = [
      { medicamento: 'Antibiótico', motivo: 'Inflamação' },
      { medicamento: 'Vermífugo', motivo: 'Prevenção' },
    ];
    expect(medicamentos).toHaveLength(2);
    medicamentos.forEach((m) => {
      expect(m.motivo).toBeTruthy();
    });
  });

  it('should have reproducao com status', () => {
    const reproducao = [
      { status: 'Confirmada' },
      { status: 'Pendente' },
    ];
    expect(reproducao).toHaveLength(2);
    reproducao.forEach((r) => {
      expect(['Confirmada', 'Pendente']).toContain(r.status);
    });
  });

  it('should have alertas ativos', () => {
    const alertas = [
      { tipo: 'Saúde', mensagem: 'Animal em observação' },
      { tipo: 'Vacinação', mensagem: 'Próxima vacinação em 10 dias' },
    ];
    expect(alertas).toHaveLength(2);
  });

  it('should calculate healthy animals', () => {
    const animais = [
      { status: 'Saudável' },
      { status: 'Saudável' },
      { status: 'Observação' },
    ];
    const saudaveis = animais.filter((a) => a.status === 'Saudável').length;
    expect(saudaveis).toBe(2);
  });
});
