import { useAuth } from '@/_core/hooks/useAuth';
import DashboardLayout from '@/components/DashboardLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Cloud,
  AlertTriangle,
  TrendingUp,
  Activity,
  Leaf,
  Zap,
  BarChart3,
  Calendar,
  MapPin,
  Droplets,
  Wind,
  Thermometer,
} from 'lucide-react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

/**
 * Dashboard Principal do AgroFácil
 * Visão geral da fazenda com clima, alertas, financeiro e atividades
 */
export default function Dashboard() {
  const { user } = useAuth();

  // Mock data for weather
  const weatherData = {
    temperature: 28,
    humidity: 65,
    windSpeed: 12,
    uvIndex: 7,
    rainfall: 2.5,
    forecast: [
      { day: 'Seg', temp: 28, rain: 10 },
      { day: 'Ter', temp: 27, rain: 20 },
      { day: 'Qua', temp: 26, rain: 30 },
      { day: 'Qui', temp: 29, rain: 5 },
      { day: 'Sex', temp: 30, rain: 0 },
    ],
  };

  // Mock alerts
  const alerts = [
    {
      id: 1,
      type: 'PEST',
      severity: 'HIGH',
      title: 'Alerta de Praga Detectada',
      message: 'Broca do milho detectada no talhão A3',
      time: '2 horas atrás',
    },
    {
      id: 2,
      type: 'DISEASE',
      severity: 'MEDIUM',
      title: 'Doença em Monitoramento',
      message: 'Ferrugem asiática em nível de alerta',
      time: '5 horas atrás',
    },
    {
      id: 3,
      type: 'CLIMATE',
      severity: 'LOW',
      title: 'Aviso Climático',
      message: 'Chuva prevista para os próximos 3 dias',
      time: '1 dia atrás',
    },
  ];

  // Mock financial summary
  const financialData = {
    totalIncome: 125000,
    totalExpense: 45000,
    profit: 80000,
    profitMargin: 64,
    monthlyData: [
      { month: 'Jan', income: 15000, expense: 5000 },
      { month: 'Fev', income: 18000, expense: 6000 },
      { month: 'Mar', income: 22000, expense: 7000 },
      { month: 'Abr', income: 25000, expense: 8000 },
      { month: 'Mai', income: 28000, expense: 9000 },
      { month: 'Jun', income: 17000, expense: 10000 },
    ],
  };

  // Mock recent activities
  const recentActivities = [
    {
      id: 1,
      type: 'CROP',
      title: 'Plantio de Soja Concluído',
      description: 'Talhão A1 - 50 hectares',
      time: '3 horas atrás',
      icon: Leaf,
    },
    {
      id: 2,
      type: 'LIVESTOCK',
      title: 'Vacinação de Gado',
      description: '45 cabeças vacinadas contra aftosa',
      time: '1 dia atrás',
      icon: Zap,
    },
    {
      id: 3,
      type: 'MAINTENANCE',
      title: 'Manutenção de Trator',
      description: 'Troca de óleo e filtros - Trator JD 7530',
      time: '2 dias atrás',
      icon: Activity,
    },
    {
      id: 4,
      type: 'ANALYSIS',
      title: 'Análise de Solo Realizada',
      description: 'Talhão A2 - Resultados disponíveis',
      time: '3 dias atrás',
      icon: Droplets,
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold">Bem-vindo, {user?.name}!</h1>
          <p className="text-muted-foreground mt-2">
            Visão geral da sua fazenda em tempo real
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Temperatura</p>
                <p className="text-3xl font-bold mt-2">{weatherData.temperature}°C</p>
              </div>
              <Thermometer className="h-12 w-12 text-orange-500 opacity-50" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Umidade</p>
                <p className="text-3xl font-bold mt-2">{weatherData.humidity}%</p>
              </div>
              <Droplets className="h-12 w-12 text-blue-500 opacity-50" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Vento</p>
                <p className="text-3xl font-bold mt-2">{weatherData.windSpeed} km/h</p>
              </div>
              <Wind className="h-12 w-12 text-cyan-500 opacity-50" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Chuva</p>
                <p className="text-3xl font-bold mt-2">{weatherData.rainfall} mm</p>
              </div>
              <Cloud className="h-12 w-12 text-slate-500 opacity-50" />
            </div>
          </Card>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Weather & Alerts */}
          <div className="lg:col-span-2 space-y-6">
            {/* Weather Forecast */}
            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-4">Previsão de 5 Dias</h2>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={weatherData.forecast}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Legend />
                  <Line
                    yAxisId="left"
                    type="monotone"
                    dataKey="temp"
                    stroke="#f97316"
                    name="Temperatura (°C)"
                  />
                  <Line
                    yAxisId="right"
                    type="monotone"
                    dataKey="rain"
                    stroke="#3b82f6"
                    name="Chuva (%)"
                  />
                </LineChart>
              </ResponsiveContainer>
            </Card>

            {/* Alerts */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold">Alertas Ativos</h2>
                <AlertTriangle className="h-5 w-5 text-red-500" />
              </div>
              <div className="space-y-3">
                {alerts.map((alert) => (
                  <div
                    key={alert.id}
                    className={`p-4 rounded-lg border-l-4 ${
                      alert.severity === 'HIGH'
                        ? 'border-red-500 bg-red-50'
                        : alert.severity === 'MEDIUM'
                          ? 'border-yellow-500 bg-yellow-50'
                          : 'border-blue-500 bg-blue-50'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="font-semibold">{alert.title}</p>
                        <p className="text-sm text-muted-foreground mt-1">
                          {alert.message}
                        </p>
                      </div>
                      <span className="text-xs text-muted-foreground whitespace-nowrap ml-4">
                        {alert.time}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="outline" className="w-full mt-4">
                Ver Todos os Alertas
              </Button>
            </Card>
          </div>

          {/* Right Column - Financial Summary */}
          <div className="space-y-6">
            <Card className="p-6 bg-gradient-to-br from-green-50 to-emerald-50">
              <h2 className="text-xl font-semibold mb-6">Resumo Financeiro</h2>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground">Receita Total</p>
                  <p className="text-2xl font-bold text-green-700 mt-1">
                    R$ {(financialData.totalIncome / 1000).toFixed(1)}k
                  </p>
                </div>
                <div className="border-t pt-4">
                  <p className="text-sm text-muted-foreground">Despesa Total</p>
                  <p className="text-2xl font-bold text-red-700 mt-1">
                    R$ {(financialData.totalExpense / 1000).toFixed(1)}k
                  </p>
                </div>
                <div className="border-t pt-4 bg-white rounded-lg p-4">
                  <p className="text-sm text-muted-foreground">Lucro Líquido</p>
                  <p className="text-3xl font-bold text-green-700 mt-1">
                    R$ {(financialData.profit / 1000).toFixed(1)}k
                  </p>
                  <p className="text-xs text-green-600 mt-2">
                    Margem: {financialData.profitMargin}%
                  </p>
                </div>
              </div>
              <Button className="w-full mt-6">Ver Detalhes Financeiros</Button>
            </Card>

            {/* Quick Actions */}
            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-4">Ações Rápidas</h2>
              <div className="space-y-2">
                <Button variant="outline" className="w-full justify-start">
                  <Leaf className="h-4 w-4 mr-2" />
                  Novo Plantio
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Zap className="h-4 w-4 mr-2" />
                  Registrar Vacinação
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Gerar Relatório
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Camera className="h-4 w-4 mr-2" />
                  Diagnóstico com IA
                </Button>
              </div>
            </Card>
          </div>
        </div>

        {/* Financial Chart */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Fluxo de Caixa - Últimos 6 Meses</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={financialData.monthlyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="income" fill="#10b981" name="Receita" />
              <Bar dataKey="expense" fill="#ef4444" name="Despesa" />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Recent Activities */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Atividades Recentes</h2>
          <div className="space-y-4">
            {recentActivities.map((activity) => {
              const Icon = activity.icon;
              return (
                <div key={activity.id} className="flex items-start gap-4 pb-4 border-b last:border-b-0">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold">{activity.title}</p>
                    <p className="text-sm text-muted-foreground">{activity.description}</p>
                    <p className="text-xs text-muted-foreground mt-1">{activity.time}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    </DashboardLayout>
  );
}

// Placeholder for Camera icon
const Camera = (props: any) => (
  <svg
    {...props}
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z" />
    <circle cx="12" cy="13" r="3" />
  </svg>
);
